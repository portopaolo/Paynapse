#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"
command -v docker >/dev/null || { echo 'BLOCKED: Docker non disponibile'; exit 2; }
command -v python3 >/dev/null || { echo 'BLOCKED: Python 3 non disponibile'; exit 2; }
python3 -c 'import psycopg' >/dev/null 2>&1 || { echo 'BLOCKED: installare psycopg 3'; exit 2; }
docker info >/dev/null 2>&1 || { echo 'BLOCKED: daemon Docker non disponibile'; exit 2; }
name="paynapse-pg-test-$$"
password="$(python3 -c 'import secrets;print(secrets.token_urlsafe(24))')"
cleanup() { docker rm -f "$name" >/dev/null 2>&1 || true; }
trap cleanup EXIT
# A random host port avoids collision with an existing database.
docker run -d --name "$name" -e POSTGRES_USER=paynapse_test -e POSTGRES_PASSWORD="$password" -e POSTGRES_DB=paynapse_test -p 127.0.0.1::5432 postgres:16-alpine >/dev/null
port="$(docker port "$name" 5432/tcp | head -1 | awk -F: '{print $NF}')"
[[ "$port" =~ ^[0-9]+$ ]] || { echo 'FAIL: port mapping'; exit 3; }
ready=0
for i in $(seq 1 60); do
  if docker exec "$name" pg_isready -U paynapse_test -d paynapse_test >/dev/null 2>&1; then ready=1; break; fi
  sleep 1
done
[[ "$ready" == 1 ]] || { echo 'FAIL: PostgreSQL not ready'; docker logs "$name"; exit 3; }
export PAYNAPSE_PG_DSN="postgresql://paynapse_test:${password}@127.0.0.1:${port}/paynapse_test"
# Never print the DSN: it contains the temporary password.
python3 -m unittest -v postgres_integration_test test_postgres_concurrency 2>&1 | tee postgres_real_test_results.log
# A successful exit is required, but only a human review of the log confirms all gates ran.
python3 verify_postgres_log.py postgres_real_test_results.log
