"""Optional real PostgreSQL integration test; run only with disposable PAYNAPSE_PG_DSN."""
import os
import unittest
from pathlib import Path
from uuid import UUID
from postgres_adapter import PayRequest, PostgresPayAdapter, connect_from_env
from pg_test_safety import validate_test_dsn

@unittest.skipUnless(os.environ.get('PAYNAPSE_PG_DSN'), 'requires disposable PAYNAPSE_PG_DSN')
class RealPostgresIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            import psycopg
        except ImportError:
            raise unittest.SkipTest('psycopg 3 not installed')
        validate_test_dsn(os.environ["PAYNAPSE_PG_DSN"])
        root = Path(__file__).parent
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                for name in ('postgresql_foundation.sql','postgresql_reservations_v09.sql','postgresql_pay_v09.sql'):
                    cur.execute((root/name).read_text())
        cls.adapter = PostgresPayAdapter(connect_from_env)

    def setUp(self):
        import uuid
        self.tenant='test_' + uuid.uuid4().hex
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('INSERT INTO paynapse.accounts(tenant_id,account_id,currency,balance_minor) VALUES (%s,%s,%s,%s),(%s,%s,%s,%s)',(self.tenant,'source','USD',1000,self.tenant,'target','USD',0))

    def test_reserve_duplicate_settle(self):
        req=PayRequest(self.tenant,'same-key','source','target','USD',250)
        first=self.adapter.reserve(req)
        again=self.adapter.reserve(req)
        self.assertEqual(first,again)
        self.assertEqual(self.adapter.settle_after_simulated_confirmation(first['operation_id'],confirmed=True),'COMPLETED')
        self.assertEqual(self.adapter.settle_after_simulated_confirmation(first['operation_id'],confirmed=True),'COMPLETED')
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT account_id,balance_minor,reserved_minor FROM paynapse.accounts WHERE tenant_id=%s ORDER BY account_id',(self.tenant,))
                self.assertEqual(cur.fetchall(),[('source',750,0),('target',250,0)])
                cur.execute('SELECT count(*),sum(delta_minor) FROM paynapse.ledger_postings WHERE operation_id=%s',(UUID(first['operation_id']),))
                self.assertEqual(cur.fetchone(),(2,0))

    def test_conflicting_duplicate_rejected(self):
        req=PayRequest(self.tenant,'key','source','target','USD',100)
        self.adapter.reserve(req)
        with self.assertRaises(Exception):
            self.adapter.reserve(PayRequest(self.tenant,'key','source','target','USD',101))

if __name__=='__main__': unittest.main()
