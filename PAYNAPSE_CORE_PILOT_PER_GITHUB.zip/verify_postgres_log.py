"""Fail closed if the real PostgreSQL test run skipped any test."""
import pathlib, re, sys

def verify(log):
    if 'skipped=' in log or re.search(r'^.*\.\.\. skipped ', log, re.M):
        raise ValueError('PostgreSQL tests were skipped')
    m = re.search(r'Ran (\d+) tests? in ', log)
    if not m or int(m.group(1)) < 5:
        raise ValueError('Expected at least five PostgreSQL integration/concurrency tests')
    if not re.search(r'^OK\s*$', log, re.M):
        raise ValueError('PostgreSQL test suite did not report OK')
    return int(m.group(1))

if __name__ == '__main__':
    try:
        count = verify(pathlib.Path(sys.argv[1]).read_text())
    except (ValueError, OSError, IndexError) as exc:
        print('FAIL:', exc, file=sys.stderr)
        sys.exit(1)
    print(f'PASS: {count} PostgreSQL tests executed without skips')
