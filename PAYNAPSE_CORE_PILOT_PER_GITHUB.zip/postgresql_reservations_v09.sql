-- PAYNAPSE Build 09: operation-scoped reservations and creation (simulation only)
-- Apply foundation, then this migration, then postgresql_pay_v09.sql.
-- Requires a fresh disposable database or a controlled migration of existing reservations.
BEGIN;
CREATE TABLE IF NOT EXISTS paynapse.operation_reservations (
 operation_id uuid PRIMARY KEY REFERENCES paynapse.money_operations(operation_id),
 tenant_id text NOT NULL,
 source_account text NOT NULL,
 amount_minor bigint NOT NULL CHECK (amount_minor > 0),
 status text NOT NULL CHECK(status IN ('ACTIVE','CONSUMED','RELEASED')),
 FOREIGN KEY (tenant_id,source_account) REFERENCES paynapse.accounts(tenant_id,account_id)
);
CREATE OR REPLACE FUNCTION paynapse.create_and_reserve_simulated(
 p_operation uuid,p_tenant text,p_key text,p_hash text,
 p_source text,p_target text,p_currency text,p_amount bigint)
RETURNS TABLE(canonical_operation_id uuid, operation_status text) LANGUAGE plpgsql AS $$
DECLARE v_existing paynapse.money_operations%ROWTYPE; v_src paynapse.accounts%ROWTYPE; v_dst paynapse.accounts%ROWTYPE;
BEGIN
 IF p_amount IS NULL OR p_amount <= 0 OR p_source=p_target OR p_tenant IS NULL OR p_key IS NULL OR p_hash IS NULL THEN
   RAISE EXCEPTION 'invalid request'; END IF;
 -- Tenant/key advisory lock serializes duplicate requests, including before insertion.
 PERFORM pg_advisory_xact_lock(hashtextextended(p_tenant || ':' || p_key, 0));
 SELECT * INTO v_existing FROM paynapse.money_operations WHERE tenant_id=p_tenant AND idempotency_key=p_key FOR UPDATE;
 IF FOUND THEN
   IF v_existing.request_hash<>p_hash OR v_existing.source_account<>p_source OR v_existing.target_account<>p_target
      OR v_existing.currency<>p_currency OR v_existing.amount_minor<>p_amount THEN
      RAISE EXCEPTION 'idempotency conflict'; END IF;
   RETURN QUERY SELECT v_existing.operation_id, v_existing.status;
   RETURN;
 END IF;
 PERFORM 1 FROM paynapse.accounts WHERE tenant_id=p_tenant AND account_id IN (p_source,p_target)
   ORDER BY account_id FOR UPDATE;
 SELECT * INTO v_src FROM paynapse.accounts WHERE tenant_id=p_tenant AND account_id=p_source;
 SELECT * INTO v_dst FROM paynapse.accounts WHERE tenant_id=p_tenant AND account_id=p_target;
 IF v_src.account_id IS NULL OR v_dst.account_id IS NULL THEN RAISE EXCEPTION 'missing account'; END IF;
 IF v_src.currency<>p_currency OR v_dst.currency<>p_currency THEN RAISE EXCEPTION 'currency mismatch'; END IF;
 IF v_src.balance_minor-v_src.reserved_minor < p_amount THEN RAISE EXCEPTION 'insufficient available funds'; END IF;
 INSERT INTO paynapse.money_operations(operation_id,tenant_id,idempotency_key,request_hash,source_account,target_account,currency,amount_minor,status)
 VALUES(p_operation,p_tenant,p_key,p_hash,p_source,p_target,p_currency,p_amount,'RESERVED');
 INSERT INTO paynapse.operation_reservations(operation_id,tenant_id,source_account,amount_minor,status)
 VALUES(p_operation,p_tenant,p_source,p_amount,'ACTIVE');
 UPDATE paynapse.accounts SET reserved_minor=reserved_minor+p_amount
 WHERE tenant_id=p_tenant AND account_id=p_source;
 RETURN QUERY SELECT p_operation, 'RESERVED'::text;
 RETURN;
END; $$;
CREATE OR REPLACE FUNCTION paynapse.release_reservation_simulated(p_operation uuid)
RETURNS text LANGUAGE plpgsql AS $$
DECLARE v_op paynapse.money_operations%ROWTYPE; v_res paynapse.operation_reservations%ROWTYPE;
BEGIN
 SELECT * INTO v_op FROM paynapse.money_operations WHERE operation_id=p_operation FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'unknown operation'; END IF;
 SELECT * INTO v_res FROM paynapse.operation_reservations WHERE operation_id=p_operation FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'missing reservation'; END IF;
 IF v_res.status='RELEASED' THEN RETURN 'RELEASED'; END IF;
 IF v_res.status='CONSUMED' OR v_op.status='COMPLETED' THEN RAISE EXCEPTION 'already settled'; END IF;
 IF v_op.status='UNCERTAIN' THEN RAISE EXCEPTION 'uncertain: verify provider outcome before release'; END IF;
 IF v_op.status<>'RESERVED' THEN RAISE EXCEPTION 'invalid state'; END IF;
 UPDATE paynapse.accounts SET reserved_minor=reserved_minor-v_res.amount_minor
 WHERE tenant_id=v_res.tenant_id AND account_id=v_res.source_account
 AND reserved_minor>=v_res.amount_minor;
 IF NOT FOUND THEN RAISE EXCEPTION 'reservation aggregate inconsistent'; END IF;
 UPDATE paynapse.operation_reservations SET status='RELEASED' WHERE operation_id=p_operation;
 UPDATE paynapse.money_operations SET status='REJECTED' WHERE operation_id=p_operation;
 RETURN 'RELEASED';
END; $$;
COMMIT;
