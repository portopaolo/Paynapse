# PAYNAPSE — Protocollo di prova PostgreSQL reale

Stato: NON ESEGUITO in questo ambiente; Docker/PostgreSQL assenti e installazione via apt bloccata da timeout.

## Esecuzione su macchina con Docker e Python 3

```bash
python3 -m pip install 'psycopg[binary]'
./run_real_postgres.sh
```

Lo script avvia PostgreSQL 16 in un container effimero accessibile solo da localhost, usa credenziali generate, esegue i test PostgreSQL esistenti e distrugge il container all'uscita. Non inserire dati reali. La prima esecuzione richiede che Docker possa scaricare l'immagine `postgres:16-alpine`.

## Gate di accettazione

- Zero test PostgreSQL saltati e zero errori
- Duplicati con stessa chiave: una sola operazione canonica
- Chiave riutilizzata con payload differente: rifiuto
- Due riserve concorrenti: nessun overspend
- Otto settlement concorrenti: una sola coppia di postings
- Bilanciamento postings per valuta
- Controlli ulteriori prima di ogni dichiarazione di completamento: RLS tenant, privileges, fallimenti transazionali, evidence chain e FX integrato.

Un test fallito è una scoperta da correggere, non un successo. Nessuna prova di produzione o fondi reali.
