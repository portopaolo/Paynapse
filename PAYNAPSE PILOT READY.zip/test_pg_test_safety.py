import unittest
from pg_test_safety import validate_test_dsn

class TestDsnGuard(unittest.TestCase):
    def test_accept_local_test_database(self):
        for dsn in ('postgresql://u:p@127.0.0.1:5432/paynapse_test', 'postgres://u:p@localhost/paynapse_test'):
            validate_test_dsn(dsn)
    def test_reject_production_and_remote(self):
        for dsn in ('postgresql://u:p@db.example.com/paynapse_test', 'postgresql://u:p@localhost/paynapse', 'postgresql://u:p@localhost/postgres', 'sqlite:///paynapse_test', 'postgresql://u:p@localhost/paynapse_test_extra'):
            with self.subTest(dsn=dsn), self.assertRaises(ValueError):
                validate_test_dsn(dsn)
