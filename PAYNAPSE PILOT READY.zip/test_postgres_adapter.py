import unittest
from uuid import UUID
from postgres_adapter import PayRequest, PostgresPayAdapter

class Cursor:
    def __init__(self, log): self.log=log
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def execute(self, sql, args): self.log.append((sql,args))
    def fetchone(self):
        if 'create_and_reserve_simulated' in self.log[-1][0]:
            return (self.log[-1][1][0], 'RESERVED')
        return ('RESERVED',)
class Conn:
    def __init__(self, log): self.log=log
    def __enter__(self): return self
    def __exit__(self,*args): pass
    def cursor(self): return Cursor(self.log)
class AdapterTests(unittest.TestCase):
    def setUp(self):
        self.log=[]; self.adapter=PostgresPayAdapter(lambda: Conn(self.log))
        self.request=PayRequest('t1','key1','a','b','USD',100)
    def test_reserve_parameterized(self):
        result=self.adapter.reserve(self.request)
        self.assertEqual(result['status'],'RESERVED')
        self.assertIn('%s',self.log[0][0]); self.assertEqual(len(self.log[0][1]),8)
        self.assertTrue(self.log[0][0].startswith("SELECT * FROM paynapse.create_and_reserve_simulated"))
        self.assertIsInstance(UUID(result['operation_id']), UUID)
    def test_duplicate_returns_canonical_id(self):
        canonical = UUID('00000000-0000-0000-0000-000000000042')
        class DuplicateCursor(Cursor):
            def fetchone(self): return (canonical, 'COMPLETED')
        class DuplicateConn(Conn):
            def cursor(self): return DuplicateCursor(self.log)
        adapter = PostgresPayAdapter(lambda: DuplicateConn(self.log))
        result = adapter.reserve(self.request, operation_id='00000000-0000-0000-0000-000000000043')
        self.assertEqual(result, {'operation_id': str(canonical), 'status': 'COMPLETED'})
    def test_bad_reserve_result_fails_closed(self):
        class BrokenCursor(Cursor):
            def fetchone(self): return ('RESERVED',)
        class BrokenConn(Conn):
            def cursor(self): return BrokenCursor(self.log)
        with self.assertRaises(RuntimeError):
            PostgresPayAdapter(lambda: BrokenConn(self.log)).reserve(self.request)
    def test_fingerprint_deterministic(self):
        self.assertEqual(self.request.fingerprint(),self.request.fingerprint())
        self.assertNotEqual(self.request.fingerprint(),PayRequest('t1','key1','a','b','USD',101).fingerprint())
    def test_reject_zero(self):
        with self.assertRaises(ValueError): self.adapter.reserve(PayRequest('t1','k','a','b','USD',0))
        self.assertEqual(self.log,[])
    def test_reject_bool_amount(self):
        with self.assertRaises(ValueError): PayRequest('t1','k','a','b','USD',True).validate()
    def test_reject_cross_currency_bad_format(self):
        with self.assertRaises(ValueError): PayRequest('t1','k','a','b','usd',10).validate()
    def test_settlement_requires_confirmation(self):
        with self.assertRaises(ValueError): self.adapter.settle_after_simulated_confirmation('00000000-0000-0000-0000-000000000001')
        self.assertEqual(self.log,[])
    def test_settlement_confirmed(self):
        self.adapter.settle_after_simulated_confirmation('00000000-0000-0000-0000-000000000001',confirmed=True)
        self.assertIn('settle_confirmed_simulated',self.log[0][0])
    def test_release_dispatched_forbidden(self):
        with self.assertRaises(ValueError): self.adapter.release_before_dispatch('00000000-0000-0000-0000-000000000001',dispatched=True)
        self.assertEqual(self.log,[])
    def test_release_before_dispatch(self):
        self.adapter.release_before_dispatch('00000000-0000-0000-0000-000000000001')
        self.assertIn('release_reservation_simulated',self.log[0][0])
if __name__=='__main__': unittest.main()
