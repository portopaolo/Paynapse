-- PAYNAPSE PostgreSQL foundation — DRAFT, NOT EXECUTED OR INTEGRATED
-- Run in a disposable test database. Requires PostgreSQL 15+.
BEGIN;
CREATE SCHEMA IF NOT EXISTS paynapse;
CREATE TABLE IF NOT EXISTS paynapse.accounts (
 tenant_id text NOT NULL, account_id text NOT NULL, currency text NOT NULL,
 balance_minor bigint NOT NULL CHECK(balance_minor >= 0),
 reserved_minor bigint NOT NULL DEFAULT 0 CHECK(reserved_minor >= 0 AND reserved_minor <= balance_minor),
 PRIMARY KEY(tenant_id,account_id), CHECK(currency ~ '^[A-Z]{3}$')
);
CREATE TABLE IF NOT EXISTS paynapse.money_operations (
 operation_id uuid PRIMARY KEY, tenant_id text NOT NULL, idempotency_key text NOT NULL,
 request_hash text NOT NULL, source_account text NOT NULL, target_account text NOT NULL,
 currency text NOT NULL, amount_minor bigint NOT NULL CHECK(amount_minor>0),
 status text NOT NULL CHECK(status IN ('CREATED','RESERVED','UNCERTAIN','COMPLETED','REJECTED')),
 UNIQUE(tenant_id,idempotency_key),
 UNIQUE(tenant_id,operation_id),
 FOREIGN KEY(tenant_id,source_account) REFERENCES paynapse.accounts(tenant_id,account_id),
 FOREIGN KEY(tenant_id,target_account) REFERENCES paynapse.accounts(tenant_id,account_id),
 CHECK(source_account<>target_account)
);
CREATE TABLE IF NOT EXISTS paynapse.ledger_postings (
 operation_id uuid NOT NULL REFERENCES paynapse.money_operations(operation_id),
 tenant_id text NOT NULL, account_id text NOT NULL, currency text NOT NULL,
 FOREIGN KEY (tenant_id,operation_id) REFERENCES paynapse.money_operations(tenant_id,operation_id),
 FOREIGN KEY (tenant_id,account_id) REFERENCES paynapse.accounts(tenant_id,account_id),
 delta_minor bigint NOT NULL CHECK(delta_minor<>0),
 PRIMARY KEY(operation_id,account_id,currency)
);
CREATE TABLE IF NOT EXISTS paynapse.evidence_events (
 seq bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
 operation_id uuid NOT NULL, event_name text NOT NULL,
 previous_hash text NOT NULL, event_hash text NOT NULL
);
CREATE OR REPLACE FUNCTION paynapse.reject_mutation() RETURNS trigger
LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'append-only table'; END; $$;
DROP TRIGGER IF EXISTS postings_append_only ON paynapse.ledger_postings;
CREATE TRIGGER postings_append_only BEFORE UPDATE OR DELETE ON paynapse.ledger_postings
FOR EACH ROW EXECUTE FUNCTION paynapse.reject_mutation();
DROP TRIGGER IF EXISTS evidence_append_only ON paynapse.evidence_events;
CREATE TRIGGER evidence_append_only BEFORE UPDATE OR DELETE ON paynapse.evidence_events
FOR EACH ROW EXECUTE FUNCTION paynapse.reject_mutation();
-- RLS requires correctly configured application roles and tenant context.
-- No tenant isolation claim is made by this draft schema.
COMMIT;
