import unittest
from kernel import Kernel
from provider_demo import PilotRouter,SimProvider,demo
class ProviderTests(unittest.TestCase):
    def setUp(self):
        self.k=Kernel();self.k.fund_demo('t','a','USD','50');self.k.fund_demo('t','b','USD','1')
        self.a=SimProvider('A',{});self.b=SimProvider('B',{})
        self.r=PilotRouter(self.k,{'A':self.a,'B':self.b})
    def op(self,provider='A'):
        import uuid
        op=self.k.create_pay('t',str(uuid.uuid4()),'a','b','USD','10')
        self.k.reserve(op);self.r.prepare(op,provider)
        return op
    def test_confirmed(self):
        op=self.op();self.a.outcomes['paynapse:'+op]='confirmed'
        self.assertEqual(self.r.dispatch_once(op),'COMPLETED')
        self.assertEqual(self.k.balance('t','a'),(4000,0))
    def test_timeout_hold_no_resend(self):
        op=self.op();self.assertEqual(self.r.dispatch_once(op),'UNCERTAIN')
        with self.assertRaises(ValueError):self.r.dispatch_once(op)
        self.assertEqual(len(self.a.calls),1)
        self.assertEqual(self.k.balance('t','a'),(5000,1000))
    def test_reconcile_confirmed_no_resend(self):
        op=self.op();self.r.dispatch_once(op)
        self.a.outcomes['paynapse:'+op]='confirmed'
        self.assertEqual(self.r.reconcile(op),'COMPLETED')
        self.assertEqual(len(self.a.calls),1)
    def test_reconcile_rejected(self):
        op=self.op('B');self.r.dispatch_once(op)
        self.b.outcomes['paynapse:'+op]='rejected'
        self.assertEqual(self.r.reconcile(op),'REJECTED')
        self.assertEqual(self.k.balance('t','a'),(5000,0))
    def test_provider_assignment_cannot_change(self):
        op=self.op('A')
        with self.assertRaises(ValueError):self.r.prepare(op,'B')
    def test_double_dispatch_rejected(self):
        op=self.op();self.a.outcomes['paynapse:'+op]='rejected';self.r.dispatch_once(op)
        with self.assertRaises(ValueError):self.r.dispatch_once(op)
    def test_demo(self):
        result=demo();self.assertEqual(result['payer'],(8000,0))
        self.assertEqual(result['merchant'],(2100,0))
        self.assertTrue(result['evidence_valid'])
if __name__=='__main__':unittest.main()
