import unittest
from verify_postgres_log import verify

class PostgreSQLGateTests(unittest.TestCase):
    def test_real_success(self):
        self.assertEqual(verify('Ran 5 tests in 0.45s\n\nOK\n'), 5)
    def test_skipped_is_failure(self):
        with self.assertRaises(ValueError): verify('Ran 5 tests in 0.45s\n\nOK (skipped=3)\n')
    def test_too_few_is_failure(self):
        with self.assertRaises(ValueError): verify('Ran 2 tests in 0.01s\n\nOK\n')
    def test_failed_is_failure(self):
        with self.assertRaises(ValueError): verify('Ran 5 tests in 0.45s\n\nFAILED (errors=1)\n')
