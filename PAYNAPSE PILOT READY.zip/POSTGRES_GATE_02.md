# PostgreSQL Gate 02 — test safety

Added a fail-closed DSN guard for the real integration and concurrency test classes. The tests refuse remote hosts and any database name other than `paynapse_test`. This reduces the risk of running schema setup against production data.

The local test suite verifies the guard. This is not a PostgreSQL execution or a financial certification. The real PostgreSQL gate remains BLOCKED until a PostgreSQL server is available.

Run `python3 -m unittest -v test_pg_test_safety` for the guard, and `./run_real_postgres.sh` on a Docker-capable host for the real gate.
