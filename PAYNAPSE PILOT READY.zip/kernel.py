
import sqlite3, json, hashlib, uuid
from decimal import Decimal, InvalidOperation

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS accounts(
 tenant TEXT NOT NULL, account TEXT NOT NULL, currency TEXT NOT NULL,
 balance INTEGER NOT NULL CHECK(balance>=0), reserved INTEGER NOT NULL DEFAULT 0
 CHECK(reserved>=0 AND reserved<=balance),
 PRIMARY KEY(tenant,account));
CREATE TABLE IF NOT EXISTS operations(
 id TEXT PRIMARY KEY, tenant TEXT NOT NULL, idem TEXT NOT NULL,
 fingerprint TEXT NOT NULL, source TEXT NOT NULL, destination TEXT NOT NULL,
 amount INTEGER NOT NULL CHECK(amount>0), currency TEXT NOT NULL,
 status TEXT NOT NULL CHECK(status IN ('CREATED','RESERVED','UNCERTAIN','COMPLETED','REJECTED')),
 UNIQUE(tenant,idem));
CREATE TABLE IF NOT EXISTS reservations(
 operation TEXT PRIMARY KEY REFERENCES operations(id), amount INTEGER NOT NULL CHECK(amount>0));
CREATE TABLE IF NOT EXISTS postings(
 operation TEXT NOT NULL REFERENCES operations(id), account TEXT NOT NULL,
 delta INTEGER NOT NULL, PRIMARY KEY(operation,account));
CREATE TABLE IF NOT EXISTS provider_results(
 operation TEXT PRIMARY KEY REFERENCES operations(id), outcome TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS evidence(
 seq INTEGER PRIMARY KEY AUTOINCREMENT, operation TEXT NOT NULL,
 event TEXT NOT NULL, prev_hash TEXT NOT NULL, digest TEXT NOT NULL);
"""
def amount_minor(value):
    try:
        d=Decimal(str(value))
        if not d.is_finite() or d<=0 or d.as_tuple().exponent < -2: raise ValueError("invalid amount")
        minor=d*100
        if minor!=minor.to_integral_value(): raise ValueError("invalid precision")
        n=int(minor)
        if n>9_000_000_000_000_000: raise ValueError("amount too large")
        return n
    except (InvalidOperation,TypeError) as e: raise ValueError("invalid amount") from e

class Kernel:
    def __init__(self, path=":memory:"):
        self.db=sqlite3.connect(path, isolation_level=None, check_same_thread=False)
        self.db.row_factory=sqlite3.Row
        self.db.executescript(SCHEMA)
    def fund_demo(self,tenant,account,currency,amount):
        n=amount_minor(amount)
        with self.db:
            self.db.execute("INSERT INTO accounts VALUES(?,?,?,?,0)",(tenant,account,currency,n))
    def _evidence(self,op,event):
        row=self.db.execute("SELECT digest FROM evidence ORDER BY seq DESC LIMIT 1").fetchone()
        prev=row["digest"] if row else "0"*64
        payload=json.dumps([op,event,prev],separators=(",",":"))
        digest=hashlib.sha256(payload.encode()).hexdigest()
        self.db.execute("INSERT INTO evidence(operation,event,prev_hash,digest) VALUES(?,?,?,?)",(op,event,prev,digest))
    def create_pay(self,tenant,idem,source,destination,currency,amount):
        if not all(isinstance(x,str) and x.strip() for x in (tenant,idem,source,destination,currency)):
            raise ValueError("missing field")
        if source==destination: raise ValueError("same account")
        n=amount_minor(amount)
        fp=hashlib.sha256(json.dumps([source,destination,currency,n],separators=(",",":")).encode()).hexdigest()
        with self.db:
            old=self.db.execute("SELECT * FROM operations WHERE tenant=? AND idem=?",(tenant,idem)).fetchone()
            if old:
                if old["fingerprint"]!=fp: raise ValueError("idempotency conflict")
                return old["id"]
            rows=self.db.execute("SELECT account,currency FROM accounts WHERE tenant=? AND account IN (?,?)",(tenant,source,destination)).fetchall()
            if len(rows)!=2 or any(r["currency"]!=currency for r in rows): raise ValueError("accounts/currency mismatch")
            op=str(uuid.uuid4())
            self.db.execute("INSERT INTO operations VALUES(?,?,?,?,?,?,?,?,?)",(op,tenant,idem,fp,source,destination,n,currency,"CREATED"))
            self._evidence(op,"CREATED")
            return op
    def reserve(self,op):
        with self.db:
            o=self._op(op)
            if o["status"]=="RESERVED": return
            if o["status"]!="CREATED": raise ValueError("invalid state")
            cur=self.db.execute("UPDATE accounts SET reserved=reserved+? WHERE tenant=? AND account=? AND balance-reserved>=?",(o["amount"],o["tenant"],o["source"],o["amount"]))
            if cur.rowcount!=1: raise ValueError("insufficient available funds")
            self.db.execute("INSERT INTO reservations VALUES(?,?)",(op,o["amount"]))
            self.db.execute("UPDATE operations SET status='RESERVED' WHERE id=?",(op,))
            self._evidence(op,"RESERVED")
    def settle_simulated(self,op,outcome):
        if outcome not in ("confirmed","timeout","rejected"): raise ValueError("invalid provider outcome")
        with self.db:
            o=self._op(op)
            if o["status"]=="COMPLETED": 
                if outcome=="confirmed": return
                raise ValueError("already completed")
            if o["status"] not in ("RESERVED","UNCERTAIN"): raise ValueError("invalid state")
            old=self.db.execute("SELECT outcome FROM provider_results WHERE operation=?",(op,)).fetchone()
            if old and old["outcome"]=="confirmed" and outcome!="confirmed": raise ValueError("conflicting confirmation")
            if outcome=="timeout":
                self.db.execute("UPDATE operations SET status='UNCERTAIN' WHERE id=?",(op,))
                self._evidence(op,"UNCERTAIN")
                return
            if outcome=="rejected":
                if old and old["outcome"]=="confirmed": raise ValueError("conflicting outcome")
                self.db.execute("UPDATE accounts SET reserved=reserved-? WHERE tenant=? AND account=?",(o["amount"],o["tenant"],o["source"]))
                self.db.execute("DELETE FROM reservations WHERE operation=?",(op,))
                self.db.execute("INSERT OR REPLACE INTO provider_results VALUES(?,?)",(op,"rejected"))
                self.db.execute("UPDATE operations SET status='REJECTED' WHERE id=?",(op,))
                self._evidence(op,"REJECTED")
                return
            self.db.execute("UPDATE accounts SET balance=balance-?, reserved=reserved-? WHERE tenant=? AND account=?",(o["amount"],o["amount"],o["tenant"],o["source"]))
            self.db.execute("UPDATE accounts SET balance=balance+? WHERE tenant=? AND account=?",(o["amount"],o["tenant"],o["destination"]))
            self.db.execute("INSERT INTO postings VALUES(?,?,?),(?,?,?)",(op,o["source"],-o["amount"],op,o["destination"],o["amount"]))
            self.db.execute("DELETE FROM reservations WHERE operation=?",(op,))
            self.db.execute("INSERT OR REPLACE INTO provider_results VALUES(?,?)",(op,"confirmed"))
            self.db.execute("UPDATE operations SET status='COMPLETED' WHERE id=?",(op,))
            self._evidence(op,"COMPLETED")
    def _op(self,op):
        row=self.db.execute("SELECT * FROM operations WHERE id=?",(op,)).fetchone()
        if not row: raise ValueError("unknown operation")
        return row
    def state(self,op): return self._op(op)["status"]
    def balance(self,tenant,account):
        r=self.db.execute("SELECT balance,reserved FROM accounts WHERE tenant=? AND account=?",(tenant,account)).fetchone()
        return tuple(r) if r else None
    def verify_evidence(self):
        prev="0"*64
        for r in self.db.execute("SELECT * FROM evidence ORDER BY seq"):
            payload=json.dumps([r["operation"],r["event"],prev],separators=(",",":"))
            if r["prev_hash"]!=prev or r["digest"]!=hashlib.sha256(payload.encode()).hexdigest(): return False
            prev=r["digest"]
        return True
