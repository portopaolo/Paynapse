"""Strictly validate unittest evidence for required real PostgreSQL test cases."""
import pathlib, re, sys

REQUIRED = {
    'test_reserve_duplicate_settle',
    'test_direct_cross_tenant_reservation_rejected',
    'test_direct_wrong_currency_posting_rejected',
    'test_settlement_rollback_on_posting_failure',
    'test_cross_tenant_posting_rejected',
    'test_conflicting_duplicate_rejected',
    'test_same_key_concurrent_reserve_is_single_operation',
    'test_concurrent_different_keys_cannot_overreserve',
    'test_concurrent_settlement_posts_exactly_once',
}

def verify(log):
    if re.search(r"\b(?:FAILED|ERROR|skipped|expected failure|unexpected success)\b", log, re.I):
        raise ValueError('Failure, error, skip or unexpected result in test log')
    lines = re.findall(r'^([a-zA-Z_][a-zA-Z_0-9]*) \(.*\) \.\.\. (ok|FAIL|ERROR|skipped.*)$', log, re.M)
    successful = {name for name, status in lines if status == 'ok'}
    missing = REQUIRED - successful
    if missing:
        raise ValueError('Missing successful real PostgreSQL cases: ' + ', '.join(sorted(missing)))
    totals = re.findall(r'^Ran (\d+) tests? in ', log, re.M)
    if len(totals) != 1 or int(totals[0]) != len(lines):
        raise ValueError('Inconsistent or missing unittest test count')
    if not re.search(r'^OK\s*$', log, re.M):
        raise ValueError('PostgreSQL test suite did not report OK')
    return len(lines)

if __name__ == '__main__':
    try:
        count = verify(pathlib.Path(sys.argv[1]).read_text())
    except (ValueError, OSError, IndexError) as exc:
        print('FAIL:', exc, file=sys.stderr)
        sys.exit(1)
    print(f'PASS: {count} verified test cases, including all {len(REQUIRED)} mandatory real PostgreSQL cases')
