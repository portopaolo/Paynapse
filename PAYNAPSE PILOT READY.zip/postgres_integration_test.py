"""Optional real PostgreSQL integration test; run only with disposable PAYNAPSE_PG_DSN."""
import os
import unittest
from pathlib import Path
from uuid import UUID
from postgres_adapter import PayRequest, PostgresPayAdapter, connect_from_env
from pg_test_safety import validate_test_dsn

@unittest.skipUnless(os.environ.get('PAYNAPSE_PG_DSN'), 'requires disposable PAYNAPSE_PG_DSN')
class RealPostgresIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            import psycopg
        except ImportError:
            raise unittest.SkipTest('psycopg 3 not installed')
        validate_test_dsn(os.environ["PAYNAPSE_PG_DSN"])
        root = Path(__file__).parent
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                for name in ('postgresql_foundation.sql','postgresql_reservations_v09.sql','postgresql_pay_v09.sql','postgresql_gate_03.sql'):
                    cur.execute((root/name).read_text())
        cls.adapter = PostgresPayAdapter(connect_from_env)

    def setUp(self):
        import uuid
        self.tenant='test_' + uuid.uuid4().hex
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('INSERT INTO paynapse.accounts(tenant_id,account_id,currency,balance_minor) VALUES (%s,%s,%s,%s),(%s,%s,%s,%s)',(self.tenant,'source','USD',1000,self.tenant,'target','USD',0))

    def test_reserve_duplicate_settle(self):
        req=PayRequest(self.tenant,'same-key','source','target','USD',250)
        first=self.adapter.reserve(req)
        again=self.adapter.reserve(req)
        self.assertEqual(first,again)
        self.assertEqual(self.adapter.settle_after_simulated_confirmation(first['operation_id'],confirmed=True),'COMPLETED')
        self.assertEqual(self.adapter.settle_after_simulated_confirmation(first['operation_id'],confirmed=True),'COMPLETED')
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT account_id,balance_minor,reserved_minor FROM paynapse.accounts WHERE tenant_id=%s ORDER BY account_id',(self.tenant,))
                self.assertEqual(cur.fetchall(),[('source',750,0),('target',250,0)])
                cur.execute('SELECT count(*),sum(delta_minor) FROM paynapse.ledger_postings WHERE operation_id=%s',(UUID(first['operation_id']),))
                self.assertEqual(cur.fetchone(),(2,0))

    def test_direct_cross_tenant_reservation_rejected(self):
        import uuid
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                op = uuid.uuid4()
                cur.execute('INSERT INTO paynapse.money_operations(operation_id,tenant_id,idempotency_key,request_hash,source_account,target_account,currency,amount_minor,status) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)', (op,self.tenant,'cross-tenant-test','hash','source','target','USD',10,'RESERVED'))
                with self.assertRaises(Exception):
                    with conn.transaction():
                        cur.execute('INSERT INTO paynapse.operation_reservations(operation_id,tenant_id,source_account,amount_minor,status) VALUES (%s,%s,%s,%s,%s)',(op,'another_tenant','source',10,'ACTIVE'))

    def test_direct_wrong_currency_posting_rejected(self):
        req=PayRequest(self.tenant,'wrong-currency','source','target','USD',10)
        op=self.adapter.reserve(req)['operation_id']
        with connect_from_env() as conn:
            with self.assertRaises(Exception):
                with conn.transaction():
                    conn.execute('INSERT INTO paynapse.ledger_postings(operation_id,tenant_id,account_id,currency,delta_minor) VALUES (%s,%s,%s,%s,%s)',(UUID(op),self.tenant,'source','EUR',-10))

    def test_settlement_rollback_on_posting_failure(self):
        """A posting failure must roll back both account updates and reservation consumption."""
        req=PayRequest(self.tenant,'rollback-failure','source','target','USD',125)
        op=self.adapter.reserve(req)['operation_id']
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT balance_minor,reserved_minor FROM paynapse.accounts WHERE tenant_id=%s AND account_id=%s',(self.tenant,'source'))
                before=cur.fetchone()
                # This conflicting posting occupies the future debit's primary key.
                cur.execute('INSERT INTO paynapse.ledger_postings(operation_id,tenant_id,account_id,currency,delta_minor) VALUES (%s,%s,%s,%s,%s)',(UUID(op),self.tenant,'source','USD',-1))
        with self.assertRaises(Exception):
            self.adapter.settle_after_simulated_confirmation(op,confirmed=True)
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT balance_minor,reserved_minor FROM paynapse.accounts WHERE tenant_id=%s AND account_id=%s',(self.tenant,'source'))
                self.assertEqual(cur.fetchone(),before)
                cur.execute('SELECT status FROM paynapse.operation_reservations WHERE operation_id=%s',(UUID(op),))
                self.assertEqual(cur.fetchone()[0],'ACTIVE')
                cur.execute('SELECT status FROM paynapse.money_operations WHERE operation_id=%s',(UUID(op),))
                self.assertEqual(cur.fetchone()[0],'RESERVED')
                cur.execute('SELECT count(*) FROM paynapse.ledger_postings WHERE operation_id=%s',(UUID(op),))
                self.assertEqual(cur.fetchone()[0],1)

    def test_cross_tenant_posting_rejected(self):
        req=PayRequest(self.tenant,'cross-tenant-posting','source','target','USD',10)
        op=self.adapter.reserve(req)['operation_id']
        with connect_from_env() as conn:
            with self.assertRaises(Exception):
                with conn.transaction():
                    conn.execute('INSERT INTO paynapse.ledger_postings(operation_id,tenant_id,account_id,currency,delta_minor) VALUES (%s,%s,%s,%s,%s)',(UUID(op),'another_tenant','source','USD',-10))

    def test_conflicting_duplicate_rejected(self):
        req=PayRequest(self.tenant,'key','source','target','USD',100)
        self.adapter.reserve(req)
        with self.assertRaises(Exception):
            self.adapter.reserve(PayRequest(self.tenant,'key','source','target','USD',101))

if __name__=='__main__': unittest.main()
