# PAYNAPSE CORE Pilot — Hardening 03

Ambito: simulazione SQLite, nessun denaro reale.

## Modifica
EXCHANGE registra un'impronta SHA-256 dei parametri di richiesta (provider, conti, valute, importo in unità minime e tasso). A parità di chiave idempotente, il replay è consentito soltanto quando l'impronta coincide. Una vecchia operazione senza impronta viene bloccata per sicurezza.

## Verifica
`python -m unittest discover -v`
Risultato locale: 114 test rilevati, 111 superati, 3 saltati (PostgreSQL non disponibile).

## Limiti ancora aperti
L'FX simulato non è atomico in ogni fase; la protezione è una misura locale e non sostituisce un'implementazione transazionale su PostgreSQL. I parametri numerici FX richiedono inoltre canonicalizzazione rigorosa prima dell'uso produttivo. Non è stata effettuata alcuna verifica PostgreSQL reale né revisione indipendente.
