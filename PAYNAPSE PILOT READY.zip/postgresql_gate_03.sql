-- Gate 03: reject inconsistent direct ledger inserts in the disposable pilot schema.
BEGIN;
CREATE OR REPLACE FUNCTION paynapse.validate_posting() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE v_op paynapse.money_operations%ROWTYPE; v_currency text;
BEGIN
 SELECT * INTO v_op FROM paynapse.money_operations WHERE operation_id=NEW.operation_id;
 IF NOT FOUND OR NEW.tenant_id IS DISTINCT FROM v_op.tenant_id THEN
  RAISE EXCEPTION 'posting tenant/operation mismatch';
 END IF;
 SELECT currency INTO v_currency FROM paynapse.accounts
 WHERE tenant_id=NEW.tenant_id AND account_id=NEW.account_id;
 IF NOT FOUND OR v_currency IS DISTINCT FROM NEW.currency OR NEW.currency IS DISTINCT FROM v_op.currency THEN
  RAISE EXCEPTION 'posting currency mismatch';
 END IF;
 IF NEW.account_id NOT IN (v_op.source_account,v_op.target_account) THEN
  RAISE EXCEPTION 'posting account not in operation';
 END IF;
 RETURN NEW;
END; $$;
DROP TRIGGER IF EXISTS validate_posting_insert ON paynapse.ledger_postings;
CREATE TRIGGER validate_posting_insert BEFORE INSERT ON paynapse.ledger_postings
FOR EACH ROW EXECUTE FUNCTION paynapse.validate_posting();
COMMIT;
