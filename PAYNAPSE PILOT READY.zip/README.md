# PAYNAPSE CORE Pilot — integrated build 01 (simulation only)

Includes the existing SQLite PAY/provider/FX/reconciliation prototypes plus an **atomic simulated FX execution** path. Source account is debited and target account credited in one SQLite transaction, with an FX execution record, postings and evidence. A reserved FX quote can be consumed only once. Provider liquidity was reserved at quote-reservation time.

**Limitations:** not real settlement; no external provider settlement; FX accounting does not yet have clearing accounts and balanced per-currency journal entries; no quote expiry, fees, tenant RLS, secure identity, production signing or PostgreSQL execution. This code is NOT a production financial ledger. Five POS functions are not complete.

Run `python -m unittest discover -p 'test_*.py' -v` in this folder.


## Build 02: Five POS service facade (SQLite only)

`pos_services.py` connects PAY, SEND, RECEIVE and digital WITHDRAW to the same simulated transfer operation and dispatch state machine. EXCHANGE uses the existing FX simulator. The four transfer actions are semantically distinct POS entrypoints but currently share one transfer accounting implementation. This is not an API server or tablet UI. FX does not yet have balanced per-currency journals, provider-side FX execution, or expiry. Run `python -m unittest discover -s . -p 'test_*.py' -v`.


## Build 03: Balanced FX simulation journal
Each FX execution now creates four posting legs, balancing USD and EUR separately against simulated provider clearing accounts. The audit checks the exact legs and per-currency zero sums. **Limitations:** SQLite still permits privileged direct edits, no immutable DB ledger or PostgreSQL integration, and clearing accounts are posting labels rather than fully modeled accounts. This is not proof of actual provider settlement.

## Build 04: Quote TTL and liquidity release
FX quotes have an expiry timestamp and a configurable TTL (default 60 seconds). Expired reserved quotes cannot execute; explicit `FXDesk.expire(quote_id)` releases simulated inventory exactly once. `reserve` also expires stale quotes. A deterministic clock is injectable for repeatable tests. Existing SQLite demo schemas gain a nullable expiry column; legacy quotes with NULL expiry remain unbounded and should not be used in production. **Important limitation:** an expired quote rejected by `execute` is not automatically released there; call `expire` or a scheduled expiry sweep. No external execution, PostgreSQL, immutable ledger, real-time expiry worker, or live financial guarantees.

## Build 05: Explicit expiry sweep
`FXDesk.sweep_expired(limit=100)` cancels expired QUOTED/RESERVED quotes and releases reserved simulated inventory in one SQLite transaction. The sweep is idempotent, bounded, and does not cancel consumed executions. It must be invoked explicitly; no background scheduler is included. The system remains SQLite simulation only, without PostgreSQL or a production ledger.

## Build 06: Account-to-journal integrity audit
`integrity.py` introduces an explicit **demo-only baseline** of funded balances (capture before operations), then checks account balances against PAY and FX postings, reserved balances against active PAY reservations, FX journal legs and the evidence hash chain. It reports anomalies without changing financial state. The baseline is not protected against privileged database modification; direct database writes and missing postings remain security risks. SQLite-only, no production ledger guarantees. Run `python -m unittest discover -s . -p "test_*.py" -v`.

## Build 07: SQLite append-only guards and PostgreSQL foundation
`ledger_guards.py` adds SQLite triggers blocking UPDATE/DELETE of PAY postings, FX postings and evidence events. These triggers do **not** protect against database administrators dropping triggers or changing other tables. Run tests with `python -m unittest discover -s . -p "test_*.py" -v`.

`postgresql_foundation.sql` is an **unexecuted PostgreSQL schema draft**, not a port of the application. PostgreSQL integration, concurrency/idempotency tests, tenant RLS, signed evidence and real accounting review remain outstanding.


## Build 08 — PostgreSQL PAY path (draft)
`postgresql_pay_v08.sql` adds a transaction-scoped, operation-locked PAY settlement function, account row locking, reservation checks, and two balanced postings. It is **not run against PostgreSQL** and is **not integrated with the Python SQLite kernel**. The function assumes that a trusted simulated confirmation was already validated and the reservation was already created; neither capability is provided by this function. No provider confirmation is validated here. No real-money use.

`test_pg_contract_v08.py` contains 6 static contract checks, not PostgreSQL integration tests. PostgreSQL execution, RLS, privilege separation, tenant isolation, reconciliation and provider evidence remain pending.


## Build 09 — PostgreSQL operation reservations (draft, not executed)
New `postgresql_reservations_v09.sql` adds operation-scoped reservations, atomic creation/reservation and guarded release. `postgresql_pay_v09.sql` consumes the exact reservation for the operation during simulated settlement. Apply in order: foundation, reservations v09, pay v09. Do not apply the old v08 settlement after v09. Static contract tests are not PostgreSQL execution. No live money, no provider validation, no RLS yet.


## Build 10 — Python adapter for PostgreSQL PAY (not database-tested)
`postgres_adapter.py` adds a Python interface to the v09 SQL functions, deterministic request fingerprints, parameterized SQL, explicit simulated confirmation, and a conservative release guard. `test_postgres_adapter.py` tests the adapter with a fake database connection. It does NOT test PostgreSQL, transaction concurrency, or actual settlement. The adapter returns a newly generated operation ID even on an idempotent duplicate; callers must not interpret it as the canonical persisted operation ID. This is a known limitation to fix before external API integration.

To test against a disposable PostgreSQL instance, install psycopg 3 and apply `postgresql_foundation.sql`, `postgresql_reservations_v09.sql`, `postgresql_pay_v09.sql` in that order. Then implement a database integration test fixture and use a dedicated non-production DSN. The current environment lacks PostgreSQL server and psycopg.


## Build 11 — Canonical idempotency identity + optional PostgreSQL integration tests
The reservation SQL now returns `(canonical_operation_id, operation_status)` so a repeated request returns the persisted operation identifier, not a fresh candidate UUID. The Python adapter validates the two-column response. Added mock adapter tests and optional real PostgreSQL integration tests for duplicate requests, conflicting payloads, and ledger balancing.

**IMPORTANT:** PostgreSQL has NOT been executed in this environment. The integration tests skip without `PAYNAPSE_PG_DSN` and `psycopg` 3. Run only against an isolated disposable database; the tests apply schema and insert rows. This is still simulated PAY only; no tenant RLS or production authorization. SQL migration is a replacement for the unexecuted v09 reservation draft, not a safe in-place migration of an existing deployed schema.


## Build 12 — Adapter SQL fix and real-concurrency test gates
The PostgreSQL adapter now expands the table-returning reservation function with `SELECT * FROM ...` rather than selecting a composite value as one column. The earlier SQL would return a single composite column and fail the two-column contract when run against PostgreSQL. This is a correctness fix, verified by local mock tests, **not** a claim of PostgreSQL execution.

Added optional real PostgreSQL concurrency gates: eight simultaneous identical idempotency keys, two competing reservations exceeding available funds, and eight simultaneous settlement attempts. These require an isolated test database and `psycopg` 3; they are skipped otherwise.

Run local suite: `python -m unittest discover -s . -p 'test_*.py' -v`. To run database tests: prepare an isolated PostgreSQL 15+ database, apply `postgresql_foundation.sql`, `postgresql_reservations_v09.sql`, `postgresql_pay_v09.sql` in order, install `psycopg[binary]`, set `PAYNAPSE_PG_DSN` for that disposable database, and run `python -m unittest -v postgres_integration_test test_postgres_concurrency`. Never use production data.

**Important:** PostgreSQL server is not available in this environment. The concurrency gates have NOT been executed. They may expose additional SQL defects. This is a simulated PAY prototype, not a validated production kernel.


## Build 13 — Provider outcome observation trail (SQLite simulation)
`provider_demo.py` now records SEND and LOOKUP observations in a separate diagnostic table and exposes `PilotRouter.audit(operation)`. After a send is attempted, the dispatch stays HELD until an explicit confirmed/rejected observation; timeouts use lookup only, never automatic resends. An invalid simulated provider response does not settle and leaves the dispatch HELD for investigation. The observation log is **not cryptographically signed** and is **not proof of external settlement**. The provider path remains SQLite-only; this build does not integrate provider/FX into PostgreSQL and PostgreSQL concurrency tests remain unexecuted.

## Build 14–16 continuation — Local POS browser demo (2026-11-22)

`demo_server.py` is a **local-only**, ephemeral SQLite browser demo for PAY, SEND, RECEIVE, EXCHANGE, and digital WITHDRAW. Start with `python demo_server.py` and open `http://127.0.0.1:8765`. It binds only to `127.0.0.1` and has **no authentication**. Do not publish or use with real customer information or real funds. Demo balances reset on restart. All provider confirmations are explicitly simulated. The browser generates a fresh idempotency key for each click; the backend supports stable keys for retries. A single in-process lock serializes requests; this does not validate distributed concurrency. Test with `python -m unittest discover -s . -p 'test_*.py'`.

**Important:** This is a runnable local UI integration, NOT a completed PostgreSQL pilot. The 3 PostgreSQL tests remain skipped without an isolated PostgreSQL server. No tenant RLS, live provider, signed settlement evidence, audited ledger, external regulatory approval, or production security. The earlier SQL PostgreSQL drafts have not been executed. Build numbering here describes the local demo scope only; full Build 16 acceptance remains blocked.
