# PAYNAPSE PostgreSQL CI Gate 02

The prior evidence verifier could pass with five unrelated green tests. This update requires the nine named real PostgreSQL integration and concurrency cases, checks the unittest total, and fails on skips/errors/failures. Static SQL tests no longer count toward the real database gate. Five synthetic-log unit tests exercise the verifier locally; these are NOT PostgreSQL integration tests. GitHub Actions must still be run with the real PostgreSQL 16 service.
