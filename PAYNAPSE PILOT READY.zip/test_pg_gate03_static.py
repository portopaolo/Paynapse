import unittest
from pathlib import Path
class Gate03Static(unittest.TestCase):
 def test_reservation_tenant_fk(self):
  sql=Path('postgresql_reservations_v09.sql').read_text()
  self.assertIn('FOREIGN KEY (tenant_id,operation_id) REFERENCES paynapse.money_operations(tenant_id,operation_id)',sql)
 def test_ledger_guard_present(self):
  sql=Path('postgresql_gate_03.sql').read_text()
  self.assertIn('BEFORE INSERT ON paynapse.ledger_postings',sql)
  self.assertIn('posting currency mismatch',sql)
