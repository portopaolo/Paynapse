"""Guard against running destructive test setup against non-local/non-test databases."""
from urllib.parse import urlsplit, unquote

def validate_test_dsn(dsn: str) -> None:
    try:
        p = urlsplit(dsn)
        db = unquote(p.path.lstrip('/'))
    except Exception as exc:
        raise ValueError('Invalid test DSN') from exc
    if p.scheme not in ('postgres', 'postgresql') or p.hostname not in ('127.0.0.1', 'localhost', '::1') or db != 'paynapse_test':
        raise ValueError('Refusing non-local or non-paynapse_test PostgreSQL DSN')
