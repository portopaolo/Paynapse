-- PAYNAPSE Build 09: operation-scoped simulated settlement, not live provider confirmation.
BEGIN;
CREATE OR REPLACE FUNCTION paynapse.settle_confirmed_simulated(p_operation uuid)
RETURNS text LANGUAGE plpgsql AS $$
DECLARE v_op paynapse.money_operations%ROWTYPE; v_res paynapse.operation_reservations%ROWTYPE;
DECLARE v_src paynapse.accounts%ROWTYPE; v_dst paynapse.accounts%ROWTYPE;
BEGIN
 SELECT * INTO v_op FROM paynapse.money_operations WHERE operation_id=p_operation FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'unknown operation'; END IF;
 IF v_op.status='COMPLETED' THEN RETURN 'COMPLETED'; END IF;
 IF v_op.status NOT IN ('RESERVED','UNCERTAIN') THEN RAISE EXCEPTION 'invalid state'; END IF;
 SELECT * INTO v_res FROM paynapse.operation_reservations WHERE operation_id=p_operation FOR UPDATE;
 IF NOT FOUND OR v_res.status<>'ACTIVE' OR v_res.amount_minor<>v_op.amount_minor
   OR v_res.tenant_id<>v_op.tenant_id OR v_res.source_account<>v_op.source_account THEN
   RAISE EXCEPTION 'missing or mismatched operation reservation'; END IF;
 PERFORM 1 FROM paynapse.accounts WHERE tenant_id=v_op.tenant_id
 AND account_id IN (v_op.source_account,v_op.target_account) ORDER BY account_id FOR UPDATE;
 SELECT * INTO v_src FROM paynapse.accounts WHERE tenant_id=v_op.tenant_id AND account_id=v_op.source_account;
 SELECT * INTO v_dst FROM paynapse.accounts WHERE tenant_id=v_op.tenant_id AND account_id=v_op.target_account;
 IF v_src.account_id IS NULL OR v_dst.account_id IS NULL THEN RAISE EXCEPTION 'missing account'; END IF;
 IF v_src.currency<>v_op.currency OR v_dst.currency<>v_op.currency THEN RAISE EXCEPTION 'currency mismatch'; END IF;
 IF v_src.reserved_minor<v_res.amount_minor OR v_src.balance_minor<v_res.amount_minor THEN RAISE EXCEPTION 'insufficient funds or aggregate reservation'; END IF;
 UPDATE paynapse.accounts SET balance_minor=balance_minor-v_res.amount_minor,
 reserved_minor=reserved_minor-v_res.amount_minor WHERE tenant_id=v_op.tenant_id AND account_id=v_op.source_account;
 UPDATE paynapse.accounts SET balance_minor=balance_minor+v_res.amount_minor
 WHERE tenant_id=v_op.tenant_id AND account_id=v_op.target_account;
 INSERT INTO paynapse.ledger_postings(operation_id,tenant_id,account_id,currency,delta_minor)
 VALUES(p_operation,v_op.tenant_id,v_op.source_account,v_op.currency,-v_res.amount_minor),
       (p_operation,v_op.tenant_id,v_op.target_account,v_op.currency,v_res.amount_minor);
 UPDATE paynapse.operation_reservations SET status='CONSUMED' WHERE operation_id=p_operation;
 UPDATE paynapse.money_operations SET status='COMPLETED' WHERE operation_id=p_operation;
 RETURN 'COMPLETED';
END; $$;
COMMIT;
