import unittest
from kernel import Kernel
from fx_settlement import FXSettlement

class FXJournalTests(unittest.TestCase):
    def setUp(self):
        self.k=Kernel();self.k.fund_demo('t','usd','USD','100.00');self.k.fund_demo('t','eur','EUR','1.00')
        self.fx=FXSettlement(self.k);self.fx.desk.set_demo_inventory('A','EUR',10000)
        self.q=self.fx.desk.quote('A','USD','EUR',1000,'0.9');self.fx.desk.reserve(self.q)
    def tearDown(self):self.k.db.close()
    def test_balanced_per_currency(self):
        op=self.fx.execute('t','fx1',self.q,'usd','eur')
        rows=self.k.db.execute('SELECT currency,SUM(delta_minor),COUNT(*) FROM fx_postings WHERE execution=? GROUP BY currency',(op,)).fetchall()
        self.assertEqual({r[0]:(r[1],r[2]) for r in rows},{'USD':(0,2),'EUR':(0,2)})
        self.assertTrue(self.fx.audit(op))
    def test_tampered_posting_detected(self):
        op=self.fx.execute('t','fx1',self.q,'usd','eur')
        self.k.db.execute('UPDATE fx_postings SET delta_minor=delta_minor+1 WHERE execution=? AND account=?',(op,'usd'))
        self.assertFalse(self.fx.audit(op))
    def test_tampered_clearing_detected(self):
        op=self.fx.execute('t','fx1',self.q,'usd','eur')
        self.k.db.execute("DELETE FROM fx_postings WHERE execution=? AND account LIKE 'FX_CLEARING:%' AND currency='EUR'",(op,))
        self.assertFalse(self.fx.audit(op))

if __name__=='__main__':unittest.main()
