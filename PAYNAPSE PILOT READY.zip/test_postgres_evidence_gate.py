import unittest
from verify_postgres_log import REQUIRED, verify

class EvidenceGateTests(unittest.TestCase):
    def make_log(self, names, suffix='OK'):
        return '\n'.join(f'{n} (postgres_integration_test.RealPostgresIntegration) ... ok' for n in names) + f'\n\nRan {len(names)} tests in 1.000s\n\n{suffix}\n'
    def test_all_mandatory_cases_accepted(self):
        self.assertEqual(verify(self.make_log(sorted(REQUIRED))), len(REQUIRED))
    def test_missing_concurrency_case_rejected(self):
        with self.assertRaises(ValueError): verify(self.make_log(sorted(REQUIRED - {'test_concurrent_settlement_posts_exactly_once'})))
    def test_skipped_case_rejected(self):
        with self.assertRaises(ValueError): verify(self.make_log(sorted(REQUIRED))+'skipped=1\n')
    def test_failed_suite_rejected(self):
        with self.assertRaises(ValueError): verify(self.make_log(sorted(REQUIRED),'FAILED (failures=1)'))
    def test_mismatched_count_rejected(self):
        with self.assertRaises(ValueError): verify(self.make_log(sorted(REQUIRED)).replace('Ran 9 tests','Ran 10 tests'))
