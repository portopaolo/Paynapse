"""FX quote + liquidity reservation prototype; no cross-currency settlement."""
from decimal import Decimal, InvalidOperation, ROUND_DOWN
import sqlite3, uuid, time

class FXDesk:
    def __init__(self, db, clock=None):
        self.db=db
        self.clock=clock if clock is not None else time.time
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS fx_inventory(
          provider TEXT NOT NULL, currency TEXT NOT NULL,
          available_minor INTEGER NOT NULL CHECK(available_minor>=0),
          PRIMARY KEY(provider,currency));
        CREATE TABLE IF NOT EXISTS fx_quotes(
          id TEXT PRIMARY KEY, provider TEXT NOT NULL,
          source_currency TEXT NOT NULL, target_currency TEXT NOT NULL,
          source_minor INTEGER NOT NULL CHECK(source_minor>0),
          target_minor INTEGER NOT NULL CHECK(target_minor>0),
          rate TEXT NOT NULL, status TEXT NOT NULL CHECK(status IN ('QUOTED','RESERVED','CANCELLED','CONSUMED')),
          expires_at INTEGER);
        """)
        # Upgrade existing SQLite demo databases without dropping their quotes.
        columns={row[1] for row in self.db.execute('PRAGMA table_info(fx_quotes)')}
        if 'expires_at' not in columns:
            self.db.execute('ALTER TABLE fx_quotes ADD COLUMN expires_at INTEGER')
    def _now(self):
        return int(self.clock())
    def _expired(self,row):
        return row['expires_at'] is not None and self._now() >= row['expires_at']
    def expire(self,q):
        """Releases simulated reserved inventory exactly once for an expired quote."""
        with self.db:
            row=self.db.execute('SELECT * FROM fx_quotes WHERE id=?',(q,)).fetchone()
            if row is None: raise ValueError('unknown quote')
            if not self._expired(row) or row['status'] in ('CANCELLED','CONSUMED'):
                return False
            if row['status']=='RESERVED':
                self.db.execute('UPDATE fx_inventory SET available_minor=available_minor+? WHERE provider=? AND currency=?',
                    (row['target_minor'],row['provider'],row['target_currency']))
            self.db.execute("UPDATE fx_quotes SET status='CANCELLED' WHERE id=? AND status IN ('QUOTED','RESERVED')",(q,))
            return True
    def sweep_expired(self,limit=100):
        """Expire up to limit stale quotes in one SQLite transaction.

        Designed for explicit invocation by the simulation harness, not a live worker.
        Returns the number of quotes newly cancelled.
        """
        if not isinstance(limit,int) or isinstance(limit,bool) or not 1<=limit<=10000:
            raise ValueError('invalid sweep limit')
        with self.db:
            ids=[r[0] for r in self.db.execute(
                "SELECT id FROM fx_quotes WHERE status IN ('QUOTED','RESERVED') "
                "AND expires_at IS NOT NULL AND expires_at<=? ORDER BY expires_at,id LIMIT ?",
                (self._now(),limit)).fetchall()]
            for quote_id in ids:
                row=self.db.execute('SELECT * FROM fx_quotes WHERE id=?',(quote_id,)).fetchone()
                if row['status']=='RESERVED':
                    result=self.db.execute('UPDATE fx_inventory SET available_minor=available_minor+? '
                        'WHERE provider=? AND currency=?',
                        (row['target_minor'],row['provider'],row['target_currency']))
                    if result.rowcount!=1: raise RuntimeError('missing inventory for reserved quote')
                self.db.execute("UPDATE fx_quotes SET status='CANCELLED' WHERE id=?",(quote_id,))
            return len(ids)
    def set_demo_inventory(self,provider,currency,minor):
        if not isinstance(minor,int) or isinstance(minor,bool) or minor<0: raise ValueError('invalid inventory')
        self.db.execute('INSERT INTO fx_inventory VALUES(?,?,?) ON CONFLICT(provider,currency) DO UPDATE SET available_minor=excluded.available_minor',(provider,currency,minor))
    def quote(self,provider,source,target,source_minor,rate,ttl_seconds=60):
        if not isinstance(ttl_seconds,int) or isinstance(ttl_seconds,bool) or not 1<=ttl_seconds<=86400: raise ValueError('invalid quote TTL')
        if not isinstance(source_minor,int) or isinstance(source_minor,bool) or source_minor<=0: raise ValueError('invalid amount')
        if source==target or not source or not target or not provider: raise ValueError('invalid pair')
        try: r=Decimal(str(rate))
        except (InvalidOperation,TypeError): raise ValueError('invalid rate')
        if not r.is_finite() or r<=0: raise ValueError('invalid rate')
        target_minor=int((Decimal(source_minor)*r).to_integral_value(rounding=ROUND_DOWN))
        if target_minor<=0 or target_minor>9_000_000_000_000_000: raise ValueError('invalid converted amount')
        q=str(uuid.uuid4())
        self.db.execute('INSERT INTO fx_quotes(id,provider,source_currency,target_currency,source_minor,target_minor,rate,status,expires_at) VALUES(?,?,?,?,?,?,?,?,?)',(q,provider,source,target,source_minor,target_minor,str(r),'QUOTED',self._now()+ttl_seconds))
        return q
    def reserve(self,q):
        with self.db:
            row=self.db.execute('SELECT * FROM fx_quotes WHERE id=?',(q,)).fetchone()
            if row is None: raise ValueError('unknown quote')
            if self._expired(row):
                self.expire(q)
                raise ValueError('expired quote')
            if row['status']=='RESERVED': return
            if row['status']!='QUOTED': raise ValueError('invalid quote state')
            result=self.db.execute('UPDATE fx_inventory SET available_minor=available_minor-? WHERE provider=? AND currency=? AND available_minor>=?',(row['target_minor'],row['provider'],row['target_currency'],row['target_minor']))
            if result.rowcount!=1: raise ValueError('insufficient provider liquidity')
            self.db.execute("UPDATE fx_quotes SET status='RESERVED' WHERE id=?",(q,))
    def cancel(self,q):
        with self.db:
            row=self.db.execute('SELECT * FROM fx_quotes WHERE id=?',(q,)).fetchone()
            if row is None: raise ValueError('unknown quote')
            if row['status']=='CANCELLED': return
            if row['status']=='CONSUMED': raise ValueError('consumed quote cannot be cancelled')
            if row['status']=='RESERVED':
                self.db.execute('UPDATE fx_inventory SET available_minor=available_minor+? WHERE provider=? AND currency=?',(row['target_minor'],row['provider'],row['target_currency']))
            self.db.execute("UPDATE fx_quotes SET status='CANCELLED' WHERE id=?",(q,))
    def inventory(self,provider,currency):
        row=self.db.execute('SELECT available_minor FROM fx_inventory WHERE provider=? AND currency=?',(provider,currency)).fetchone()
        return None if row is None else row[0]
