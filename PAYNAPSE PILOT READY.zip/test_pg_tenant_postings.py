import unittest
from pathlib import Path
P=Path(__file__).resolve().parent
class TenantPostingsContract(unittest.TestCase):
    def test_posting_belongs_to_operation_tenant(self):
        s=(P/'postgresql_foundation.sql').read_text()
        self.assertIn('FOREIGN KEY (tenant_id,operation_id) REFERENCES paynapse.money_operations(tenant_id,operation_id)',s)
        self.assertIn('UNIQUE(tenant_id,operation_id)',s)
    def test_posting_account_belongs_to_same_tenant(self):
        s=(P/'postgresql_foundation.sql').read_text()
        self.assertIn('FOREIGN KEY (tenant_id,account_id) REFERENCES paynapse.accounts(tenant_id,account_id)',s)
    def test_settlement_writes_tenant_id(self):
        s=(P/'postgresql_pay_v09.sql').read_text()
        self.assertIn('ledger_postings(operation_id,tenant_id,account_id,currency,delta_minor)',s)
        self.assertEqual(s.count('p_operation,v_op.tenant_id,'),2)
if __name__=='__main__': unittest.main()
