import unittest
from kernel import Kernel
from fx import FXDesk
from fx_settlement import FXSettlement

class QuoteExpiryTests(unittest.TestCase):
    def setUp(self):
        self.now=1000
        self.k=Kernel()
        self.k.fund_demo('t','usd','USD','100.00')
        self.k.fund_demo('t','eur','EUR','1.00')
        self.fx=FXSettlement(self.k)
        self.fx.desk.clock=lambda:self.now
        self.fx.desk.set_demo_inventory('A','EUR',10000)
    def tearDown(self): self.k.db.close()
    def quote(self,ttl=10):
        return self.fx.desk.quote('A','USD','EUR',1000,'0.9',ttl_seconds=ttl)
    def test_expiry_boundary_prevents_execution(self):
        q=self.quote();self.fx.desk.reserve(q);self.now=1010
        with self.assertRaisesRegex(ValueError,'expired'):self.fx.execute('t','x',q,'usd','eur')
        self.assertEqual(self.k.balance('t','usd'),(10000,0))
        self.assertEqual(self.fx.desk.inventory('A','EUR'),9100)
        self.assertTrue(self.fx.desk.expire(q))
        self.assertEqual(self.fx.desk.inventory('A','EUR'),10000)
    def test_expire_twice_never_double_releases(self):
        q=self.quote();self.fx.desk.reserve(q);self.now=1011
        self.assertTrue(self.fx.desk.expire(q));self.assertFalse(self.fx.desk.expire(q))
        self.assertEqual(self.fx.desk.inventory('A','EUR'),10000)
    def test_expired_unreserved_quote_cannot_reserve(self):
        q=self.quote();self.now=1010
        with self.assertRaisesRegex(ValueError,'expired'):self.fx.desk.reserve(q)
        self.assertEqual(self.k.db.execute('SELECT status FROM fx_quotes WHERE id=?',(q,)).fetchone()[0],'CANCELLED')
    def test_before_expiry_execution_succeeds(self):
        q=self.quote();self.fx.desk.reserve(q);self.now=1009
        op=self.fx.execute('t','x',q,'usd','eur')
        self.assertTrue(self.fx.audit(op))
        self.now=2000
        self.assertFalse(self.fx.desk.expire(q))
        self.assertEqual(self.fx.desk.inventory('A','EUR'),9100)
    def test_invalid_ttl_rejected(self):
        for ttl in (0,-1,1.5,True,86401):
            with self.subTest(ttl=ttl),self.assertRaises(ValueError):self.quote(ttl)
    def test_expired_reserved_cannot_reserve_again(self):
        q=self.quote();self.fx.desk.reserve(q);self.now=1011
        with self.assertRaisesRegex(ValueError,'expired'):self.fx.desk.reserve(q)
        self.assertEqual(self.fx.desk.inventory('A','EUR'),10000)
