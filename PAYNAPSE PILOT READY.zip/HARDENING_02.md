# PAYNAPSE Hardening 02 — local HTTP boundary

Added strict Host allowlist (localhost/127.0.0.1:8765), same-origin validation on browser POSTs, unknown JSON field rejection, anti-framing and no-referrer headers. These are local-demo defense-in-depth measures only. Requests without Origin remain accepted for CLI testing, and the demo has no authentication, CSRF token, or production-grade network security. Never expose beyond loopback or use real funds. PostgreSQL remains unexecuted and is NOT validated by these tests.
