import unittest
from postgres_adapter import PayRequest, PostgresPayAdapter

class AdapterSQLShapeTests(unittest.TestCase):
    def test_set_returning_function_is_expanded_to_two_columns(self):
        log=[]
        class Cursor:
            def __enter__(self): return self
            def __exit__(self,*args): return False
            def execute(self,sql,args): log.append((sql,args))
            def fetchone(self): return ('00000000-0000-0000-0000-000000000001','RESERVED')
        class Conn:
            def __enter__(self): return self
            def __exit__(self,*args): return False
            def cursor(self): return Cursor()
        result=PostgresPayAdapter(lambda: Conn()).reserve(PayRequest('t','k','a','b','USD',10))
        self.assertEqual(result['status'],'RESERVED')
        self.assertTrue(log[0][0].startswith('SELECT * FROM paynapse.create_and_reserve_simulated('))
        self.assertEqual(len(log[0][1]),8)

if __name__=='__main__': unittest.main()
