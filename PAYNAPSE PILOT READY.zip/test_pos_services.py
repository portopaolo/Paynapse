import unittest
from pos_services import POSServices

class TestPOSServices(unittest.TestCase):
    def setUp(self):
        self.p=POSServices()
        for account,currency,amount in [('payer','USD','100.00'),('merchant','USD','1.00'),('friend','USD','1.00'),('wallet','USD','1.00'),('incoming','USD','100.00'),('eur','EUR','1.00')]:
            self.p.kernel.fund_demo('t',account,currency,amount)
        self.p.fx.desk.set_demo_inventory('A','EUR',100000)

    def complete(self,method,idem,src,dst):
        op=getattr(self.p,method)('t',idem,src,dst,'USD','10.00')
        self.p.providers['A'].outcomes['paynapse:'+op]='confirmed'
        self.assertEqual(self.p.dispatch(op),'COMPLETED')
        self.assertEqual(self.p.receipt('t',idem)['state'],'COMPLETED')
        self.assertEqual(self.p.kernel.db.execute('SELECT SUM(delta) FROM postings WHERE operation=?',(op,)).fetchone()[0],0)
        return op

    def test_pay(self): self.complete('pay','p','payer','merchant')
    def test_send(self): self.complete('send','s','payer','friend')
    def test_receive(self): self.complete('receive','r','incoming','payer')
    def test_withdraw(self): self.complete('withdraw','w','payer','wallet')
    def test_exchange(self):
        op=self.p.exchange('t','fx','A','payer','eur','USD','EUR',1000,'0.9')
        self.assertTrue(self.p.receipt('t','fx')['fx_audit'])
        self.assertEqual(self.p.exchange('t','fx','A','payer','eur','USD','EUR',1000,'0.9'),op)
    def test_timeout_no_retry(self):
        op=self.p.pay('t','timeout','payer','merchant','USD','10.00')
        self.assertEqual(self.p.dispatch(op),'UNCERTAIN')
        with self.assertRaises(ValueError): self.p.dispatch(op)
        self.p.providers['A'].outcomes['paynapse:'+op]='confirmed'
        self.assertEqual(self.p.reconcile(op),'COMPLETED')
        self.assertEqual(self.p.providers['A'].calls.count('paynapse:'+op),1)
    def test_cross_service_idem_conflict(self):
        self.p.pay('t','same','payer','merchant','USD','10.00')
        with self.assertRaises(ValueError): self.p.send('t','same','payer','merchant','USD','10.00')
    def test_provider_conflict(self):
        self.p.pay('t','same','payer','merchant','USD','10.00',provider='A')
        with self.assertRaises(ValueError): self.p.pay('t','same','payer','merchant','USD','10.00',provider='B')
    def test_insufficient_liquidity_rolls_back_quote(self):
        self.p.fx.desk.set_demo_inventory('A','EUR',0)
        with self.assertRaises(ValueError): self.p.exchange('t','bad','A','payer','eur','USD','EUR',1000,'0.9')
        self.assertEqual(self.p.kernel.db.execute("SELECT COUNT(*) FROM fx_quotes WHERE status!='CANCELLED'").fetchone()[0],0)

if __name__=='__main__': unittest.main()
