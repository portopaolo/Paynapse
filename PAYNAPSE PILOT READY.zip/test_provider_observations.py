import unittest
from kernel import Kernel
from provider_demo import PilotRouter,SimProvider

class ProviderObservationTests(unittest.TestCase):
    def setUp(self):
        self.k=Kernel()
        self.k.fund_demo('t','source','USD','50')
        self.k.fund_demo('t','target','USD','1')
        self.provider=SimProvider('A',{})
        self.router=PilotRouter(self.k,{'A':self.provider})
        self.op=self.k.create_pay('t','unique','source','target','USD','10')
        self.k.reserve(self.op)
        self.router.prepare(self.op,'A')
        self.key='paynapse:'+self.op

    def test_timeout_then_lookup_confirmed_without_resend(self):
        self.assertEqual(self.router.dispatch_once(self.op),'UNCERTAIN')
        self.provider.outcomes[self.key]='confirmed'
        self.assertEqual(self.router.reconcile(self.op),'COMPLETED')
        audit=self.router.audit(self.op)
        self.assertEqual(audit['send_attempts'],1)
        self.assertEqual([x['source'] for x in audit['observations']],['SEND','LOOKUP'])
        self.assertEqual([x['outcome'] for x in audit['observations']],['timeout','confirmed'])
        self.assertEqual(self.provider.calls,[self.key])

    def test_repeated_timeout_keeps_reservation(self):
        self.router.dispatch_once(self.op)
        self.assertEqual(self.router.reconcile(self.op),'UNCERTAIN')
        self.assertEqual(self.k.balance('t','source'),(5000,1000))
        self.assertEqual(self.router.audit(self.op)['send_attempts'],1)

    def test_rejected_lookup_releases_only_once(self):
        self.router.dispatch_once(self.op)
        self.provider.outcomes[self.key]='rejected'
        self.assertEqual(self.router.reconcile(self.op),'REJECTED')
        self.assertEqual(self.k.balance('t','source'),(5000,0))
        with self.assertRaises(ValueError):self.router.reconcile(self.op)

    def test_cannot_reassign_after_timeout(self):
        self.router.dispatch_once(self.op)
        with self.assertRaises(ValueError):self.router.prepare(self.op,'B')

    def test_audit_unknown_operation(self):
        with self.assertRaises(ValueError):self.router.audit('not-an-operation')

    def test_invalid_provider_outcome_does_not_settle(self):
        self.provider.outcomes[self.key]='not-a-valid-outcome'
        with self.assertRaises(ValueError):self.router.dispatch_once(self.op)
        self.assertEqual(self.k.state(self.op),'RESERVED')
        self.assertEqual(self.router.audit(self.op)['dispatch_state'],'HELD')
        self.assertEqual(self.router.audit(self.op)['observations'],[])
        self.assertEqual(self.router.audit(self.op)['send_attempts'],1)

if __name__=='__main__':unittest.main()
