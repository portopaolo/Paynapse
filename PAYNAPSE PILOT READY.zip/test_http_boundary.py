import unittest
from demo_server import trusted_local_request, Demo

class LocalHTTPBoundaryTests(unittest.TestCase):
    def test_loopback_hosts(self):
        self.assertTrue(trusted_local_request('127.0.0.1:8765'))
        self.assertTrue(trusted_local_request('localhost:8765'))
        for host in ('evil.example','evil.example:8765','127.0.0.1:9999','[::1]:8765','127.0.0.1:8765.evil.example',''):
            self.assertFalse(trusted_local_request(host),host)
    def test_origin_same_authority(self):
        self.assertTrue(trusted_local_request('127.0.0.1:8765','http://127.0.0.1:8765'))
        self.assertTrue(trusted_local_request('localhost:8765','http://localhost:8765'))
        for origin in ('https://127.0.0.1:8765','http://evil.example','http://localhost:8765','null','http://127.0.0.1:8765.evil.example'):
            self.assertFalse(trusted_local_request('127.0.0.1:8765',origin),origin)
    def test_demo_idempotency_regression(self):
        demo=Demo();p={'action':'PAY','amount':'1.00','provider':'A','idem':'security-regression'}
        self.assertEqual(demo.execute(p)['receipt']['operation'],demo.execute(p)['receipt']['operation'])
