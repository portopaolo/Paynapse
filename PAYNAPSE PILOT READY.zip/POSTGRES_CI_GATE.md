# PAYNAPSE PostgreSQL CI gate — execution pending

A GitHub Actions workflow at `.github/workflows/postgres-integration.yml` provisions **actual PostgreSQL 16** in an isolated CI service container, installs psycopg 3, runs the existing integration/concurrency tests, and saves the test log even if tests fail.

This is **not** evidence of passing PostgreSQL tests: no hosted CI run has occurred in this environment. The workflow will surface SQL and concurrency defects that must be corrected before investor-demo acceptance.

To execute: commit the repository contents at repository root to a private GitHub repository with Actions enabled; select **Actions → PAYNAPSE PostgreSQL Integration Gate → Run workflow**, or push a change. Inspect the job log and the `paynapse-postgres-test-evidence` artifact. A green run with zero skipped tests is required; failures are blocking.

Use a private repository; never upload secrets, real financial records, or live provider credentials. The CI database and credentials are temporary and for synthetic test data only. This workflow does not validate real settlement, security review, or production readiness.
