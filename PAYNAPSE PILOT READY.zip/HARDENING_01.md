# PAYNAPSE — Financial Kernel hardening 01

This is an incremental patch of the local demo, not a production release.

## Fixed in the PostgreSQL DRAFT
The previous `ledger_postings` table did not bind its account to the operation tenant. A posting could therefore name an account belonging to another tenant, or a nonexistent account, without violating its original foreign keys. This patch adds `tenant_id` and composite foreign keys to the operation and account, and adjusts simulated settlement inserts.

## Execution status
Local unit/static tests can run here. PostgreSQL SQL execution and concurrency testing remain **unverified**. These SQL files are for a **fresh disposable test database**, not an in-place production migration.

## Open blocking findings
- PostgreSQL server and real concurrent tests not yet run.
- `settle_confirmed_simulated` has no database-level proof of provider confirmation; restrict EXECUTE privileges and add trusted evidence verification before any production use.
- RLS, role separation, append-only protections against privileged roles, evidence signing and independent accounting/security review are outstanding.
- FX and provider flow remain SQLite demo paths.
