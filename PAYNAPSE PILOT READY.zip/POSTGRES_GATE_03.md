# PostgreSQL Gate 03 — Tenant and currency constraints

Added composite tenant/operation FK on operation_reservations, plus a PostgreSQL trigger rejecting ledger inserts with wrong tenant, currency or account outside the operation. Added two real PostgreSQL negative tests and two local static checks. The PostgreSQL tests are **not executed here**. The trigger is pilot-only; the final production design needs database roles, RLS, migration discipline, and full accounting invariant enforcement.
