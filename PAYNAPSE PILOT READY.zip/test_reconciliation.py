import unittest
from kernel import Kernel
from provider_demo import PilotRouter, SimProvider
from reconciliation import audit

class ReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.k=Kernel()
        self.k.fund_demo('t','payer','USD','100.00')
        self.k.fund_demo('t','merchant','USD','1.00')
        self.p=SimProvider('A',{})
        self.r=PilotRouter(self.k,{'A':self.p})
    def operation(self,outcome):
        op=self.k.create_pay('t',outcome,'payer','merchant','USD','10.00')
        self.k.reserve(op);self.r.prepare(op,'A')
        self.p.outcomes['paynapse:'+op]=outcome
        self.r.dispatch_once(op)
        return op
    def test_confirmed_clean(self):
        self.operation('confirmed');self.assertEqual(audit(self.k)['status'],'PASS')
    def test_rejected_clean(self):
        self.operation('rejected');self.assertEqual(audit(self.k)['status'],'PASS')
    def test_uncertain_clean(self):
        self.operation('timeout');self.assertEqual(audit(self.k)['status'],'PASS')
    def test_detect_corrupted_posting(self):
        op=self.operation('confirmed')
        self.k.db.execute('UPDATE postings SET delta=delta+1 WHERE operation=? AND delta>0',(op,))
        self.assertIn('COMPLETED_POSTINGS_INVALID',[x['reason'] for x in audit(self.k)['issues']])
    def test_detect_missing_provider_confirmation(self):
        op=self.operation('confirmed')
        self.k.db.execute('DELETE FROM provider_results WHERE operation=?',(op,))
        self.assertIn('COMPLETED_WITHOUT_CONFIRMATION',[x['reason'] for x in audit(self.k)['issues']])
    def test_detect_reserved_projection_mismatch(self):
        self.operation('timeout')
        self.k.db.execute("UPDATE accounts SET reserved=0 WHERE tenant='t' AND account='payer'")
        self.assertIn('ACCOUNT_RESERVE_MISMATCH',[x['reason'] for x in audit(self.k)['issues']])
    def test_detect_evidence_tamper(self):
        self.operation('confirmed')
        self.k.db.execute("UPDATE evidence SET event='FAKE' WHERE seq=1")
        self.assertIn('EVIDENCE_CHAIN_INVALID',[x['reason'] for x in audit(self.k)['issues']])

if __name__=='__main__':unittest.main()
