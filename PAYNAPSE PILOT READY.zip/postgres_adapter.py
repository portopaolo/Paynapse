"""PostgreSQL PAY pilot adapter; simulated only. Requires psycopg 3 at runtime.

All calls run in explicit transactions. No automatic settlement on a network timeout.
"""
from dataclasses import dataclass
from hashlib import sha256
from uuid import UUID, uuid4
import json


@dataclass(frozen=True)
class PayRequest:
    tenant: str
    idempotency_key: str
    source: str
    target: str
    currency: str
    amount_minor: int

    def validate(self):
        if any(not isinstance(x, str) or not x.strip() for x in (self.tenant, self.idempotency_key, self.source, self.target, self.currency)):
            raise ValueError("missing or invalid request field")
        if self.source == self.target or type(self.amount_minor) is not int or self.amount_minor <= 0:
            raise ValueError("invalid accounts or amount")
        if len(self.currency) != 3 or not self.currency.isalpha() or self.currency != self.currency.upper():
            raise ValueError("invalid currency")
        return self

    def fingerprint(self):
        self.validate()
        payload = [self.tenant, self.idempotency_key, self.source, self.target, self.currency, self.amount_minor]
        return sha256(json.dumps(payload, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()


class PostgresPayAdapter:
    def __init__(self, connection_factory):
        self.connection_factory = connection_factory

    def _call(self, sql, args, *, expected_columns=1):
        # Connection factory must return a psycopg-compatible context-managed connection.
        with self.connection_factory() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, args)
                row = cur.fetchone()
                if row is None or len(row) != expected_columns:
                    raise RuntimeError("database did not return one status")
                return row[0] if expected_columns == 1 else row

    def reserve(self, request: PayRequest, operation_id=None):
        request.validate()
        operation_id = UUID(str(operation_id)) if operation_id is not None else uuid4()
        canonical_id, status = self._call(
            "SELECT * FROM paynapse.create_and_reserve_simulated(%s,%s,%s,%s,%s,%s,%s,%s)",
            (operation_id, request.tenant, request.idempotency_key, request.fingerprint(),
             request.source, request.target, request.currency, request.amount_minor), expected_columns=2)
        return {"operation_id": str(UUID(str(canonical_id))), "status": status}

    def settle_after_simulated_confirmation(self, operation_id, *, confirmed=False):
        if confirmed is not True:
            raise ValueError("explicit simulated confirmation required; never settle on timeout")
        return self._call("SELECT paynapse.settle_confirmed_simulated(%s)", (UUID(str(operation_id)),))

    def release_before_dispatch(self, operation_id, *, dispatched=False):
        if dispatched is not False:
            raise ValueError("cannot release dispatched/uncertain operation without reconciliation")
        return self._call("SELECT paynapse.release_reservation_simulated(%s)", (UUID(str(operation_id)),))


def connect_from_env():
    import os
    import psycopg  # optional dependency; not available in this build environment
    dsn = os.environ.get("PAYNAPSE_PG_DSN")
    if not dsn:
        raise RuntimeError("PAYNAPSE_PG_DSN is required")
    return psycopg.connect(dsn)
