import unittest
from kernel import Kernel
from fx_settlement import FXSettlement

class ExpirySweepTests(unittest.TestCase):
    def setUp(self):
        self.now=100
        self.k=Kernel()
        self.fx=FXSettlement(self.k)
        self.fx.desk.clock=lambda: self.now
        self.fx.desk.set_demo_inventory('A','EUR',10000)
    def tearDown(self): self.k.db.close()
    def quote(self,ttl=10):
        return self.fx.desk.quote('A','USD','EUR',1000,'0.9',ttl_seconds=ttl)
    def test_sweep_releases_reserved_once(self):
        q=self.quote();self.fx.desk.reserve(q)
        self.now=110
        self.assertEqual(self.fx.desk.sweep_expired(),1)
        self.assertEqual(self.fx.desk.inventory('A','EUR'),10000)
        self.assertEqual(self.fx.desk.sweep_expired(),0)
        self.assertEqual(self.fx.desk.inventory('A','EUR'),10000)
    def test_sweep_handles_unreserved(self):
        q=self.quote();self.now=110
        self.assertEqual(self.fx.desk.sweep_expired(),1)
        self.assertEqual(self.k.db.execute('SELECT status FROM fx_quotes WHERE id=?',(q,)).fetchone()[0],'CANCELLED')
    def test_sweep_respects_expiry_and_limit(self):
        a=self.quote(5);b=self.quote(10)
        self.fx.desk.reserve(a);self.fx.desk.reserve(b)
        self.now=105
        self.assertEqual(self.fx.desk.sweep_expired(limit=1),1)
        self.assertEqual(self.fx.desk.inventory('A','EUR'),9100)
        self.now=110
        self.assertEqual(self.fx.desk.sweep_expired(limit=1),1)
        self.assertEqual(self.fx.desk.inventory('A','EUR'),10000)
    def test_consumed_quote_not_cancelled(self):
        self.k.fund_demo('t','usd','USD','20.00')
        self.k.fund_demo('t','eur','EUR','1.00')
        q=self.quote();self.fx.desk.reserve(q)
        op=self.fx.execute('t','idem',q,'usd','eur')
        self.now=200
        self.assertEqual(self.fx.desk.sweep_expired(),0)
        self.assertTrue(self.fx.audit(op))
    def test_invalid_limit(self):
        for limit in (0,-1,True,1.2,10001):
            with self.subTest(limit=limit),self.assertRaises(ValueError):self.fx.desk.sweep_expired(limit)
    def test_multiple_quotes_no_double_release(self):
        a=self.quote();b=self.quote()
        self.fx.desk.reserve(a);self.fx.desk.reserve(b)
        self.now=110
        self.assertEqual(self.fx.desk.sweep_expired(),2)
        self.assertEqual(self.fx.desk.inventory('A','EUR'),10000)
        self.assertEqual(self.fx.desk.sweep_expired(),0)
