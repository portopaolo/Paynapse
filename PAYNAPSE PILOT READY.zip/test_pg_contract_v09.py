import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class PostgresContractV09(unittest.TestCase):
 def test_operation_scoped_reservation(self):
  sql=(ROOT/'postgresql_reservations_v09.sql').read_text()
  self.assertIn('operation_id uuid PRIMARY KEY',sql)
  self.assertIn('pg_advisory_xact_lock',sql)
 def test_prevent_uncertain_release(self):
  sql=(ROOT/'postgresql_reservations_v09.sql').read_text()
  self.assertIn("v_op.status='UNCERTAIN'",sql)
 def test_reservation_consumed(self):
  sql=(ROOT/'postgresql_pay_v09.sql').read_text()
  self.assertIn("status='CONSUMED'",sql)
  self.assertIn("v_res.status<>'ACTIVE'",sql)
 def test_idempotency_conflict(self):
  sql=(ROOT/'postgresql_reservations_v09.sql').read_text()
  self.assertIn('idempotency conflict',sql)
 def test_sql_transaction_boundary(self):
  for name in ['postgresql_reservations_v09.sql','postgresql_pay_v09.sql']:
   sql=(ROOT/name).read_text().strip()
   self.assertIn('BEGIN;',sql)
   self.assertTrue(sql.endswith('COMMIT;'))
if __name__=='__main__': unittest.main()
