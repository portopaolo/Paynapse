# Hardening 04 — Atomicità EXCHANGE POS (SQLite simulato)

Il percorso EXCHANGE ora esegue quote, prenotazione della liquidità simulata, addebito/accredito, quattro registrazioni FX, evidenza, consumo quote e registrazione POS nella stessa transazione SQLite. Un fallimento della scrittura finale POS provoca rollback di tutti i cambiamenti, incluso il ripristino dell'inventario. Sono stati aggiunti quattro test, compresa un'iniezione di errore tramite trigger SQLite.

**Limiti:** il metodo EXCHANGE opera su una sola connessione SQLite e non copre alcun provider esterno né PostgreSQL. Il codice di demo effettua un commit delle scritture di preparazione già pendenti prima di iniziare `BEGIN IMMEDIATE`; non usare questo comportamento in un sistema multi-request o con fondi reali. I test PostgreSQL restano saltati. Il percorso di FX non è una prova di regolamento interbancario. Restano aperti crash/recovery, concorrenza multi-processo, audit indipendente e isolamento dei tenant.

Eseguire: `python -m unittest discover -q`.
