"""Failure injection for SQLite-only atomic POS FX demo."""
import unittest
from kernel import Kernel
from pos_services import POSServices

class AtomicFXPOSTests(unittest.TestCase):
    def setUp(self):
        self.k=Kernel()
        self.k.fund_demo('t','usd','USD','100.00')
        self.k.fund_demo('t','eur','EUR','1.00')
        self.p=POSServices(self.k)
        self.p.fx.desk.set_demo_inventory('A','EUR',10000)
        self.k.db.commit()
    def tearDown(self):
        self.k.db.close()
    def exchange(self, idem='fx-1'):
        return self.p.exchange('t',idem,'A','usd','eur','USD','EUR',1000,'0.9')
    def test_success_is_balanced_and_idempotent(self):
        op=self.exchange()
        self.assertTrue(self.p.fx.audit(op))
        self.assertEqual(op,self.exchange())
        self.assertEqual(self.k.balance('t','usd'),(9000,0))
        self.assertEqual(self.p.fx.desk.inventory('A','EUR'),9100)
        self.assertEqual(self.k.db.execute('SELECT COUNT(*) FROM fx_executions').fetchone()[0],1)
    def test_pos_receipt_insert_failure_rolls_back_everything(self):
        self.k.db.execute("CREATE TRIGGER reject_pos_fx BEFORE INSERT ON pos_requests WHEN NEW.service='EXCHANGE' BEGIN SELECT RAISE(ABORT,'injected failure'); END")
        self.k.db.commit()
        with self.assertRaisesRegex(Exception,'injected failure'):
            self.exchange()
        self.assertEqual(self.k.balance('t','usd'),(10000,0))
        self.assertEqual(self.k.balance('t','eur'),(100,0))
        self.assertEqual(self.p.fx.desk.inventory('A','EUR'),10000)
        for table in ('fx_quotes','fx_executions','fx_postings','pos_requests','fx_pos_fingerprints'):
            self.assertEqual(self.k.db.execute('SELECT COUNT(*) FROM '+table).fetchone()[0],0,table)
    def test_insufficient_provider_inventory_leaves_no_quote(self):
        self.p.fx.desk.set_demo_inventory('A','EUR',10)
        self.k.db.commit()
        with self.assertRaisesRegex(ValueError,'liquidity'):
            self.exchange()
        self.assertEqual(self.k.db.execute('SELECT COUNT(*) FROM fx_quotes').fetchone()[0],0)
        self.assertEqual(self.k.balance('t','usd'),(10000,0))
    def test_insufficient_client_funds_restores_provider_inventory(self):
        with self.assertRaisesRegex(ValueError,'source funds'):
            self.p.exchange('t','big','A','usd','eur','USD','EUR',11000,'0.9')
        self.assertEqual(self.p.fx.desk.inventory('A','EUR'),10000)
        self.assertEqual(self.k.db.execute('SELECT COUNT(*) FROM fx_quotes').fetchone()[0],0)

if __name__=='__main__': unittest.main()
