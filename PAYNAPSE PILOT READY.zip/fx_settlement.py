"""Simulation-only FX settlement. Never use with real funds."""
import sqlite3, uuid, hashlib, json
from fx import FXDesk

class FXSettlement:
    def __init__(self, kernel):
        self.k=kernel
        self.db=kernel.db
        self.desk=FXDesk(self.db)
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS fx_executions(
          id TEXT PRIMARY KEY, tenant TEXT NOT NULL, idem TEXT NOT NULL,
          quote TEXT NOT NULL UNIQUE REFERENCES fx_quotes(id),
          source_account TEXT NOT NULL, target_account TEXT NOT NULL,
          fingerprint TEXT NOT NULL,
          status TEXT NOT NULL CHECK(status IN ('COMPLETED')),
          UNIQUE(tenant,idem));
        CREATE TABLE IF NOT EXISTS fx_postings(
          execution TEXT NOT NULL REFERENCES fx_executions(id),
          account TEXT NOT NULL, currency TEXT NOT NULL,
          delta_minor INTEGER NOT NULL,
          PRIMARY KEY(execution,account,currency));
        """)
    def execute(self,tenant,idem,quote_id,source_account,target_account):
        with self.db:
            return self.execute_in_transaction(tenant,idem,quote_id,source_account,target_account)

    def execute_in_transaction(self,tenant,idem,quote_id,source_account,target_account):
        """Caller owns transaction; used for atomic POS quote/reserve/settle."""
        if not all(isinstance(v,str) and v.strip() for v in (tenant,idem,quote_id,source_account,target_account)):
            raise ValueError('missing FX field')
        if source_account==target_account: raise ValueError('same account')
        fp=hashlib.sha256(json.dumps([quote_id,source_account,target_account],separators=(',',':')).encode()).hexdigest()
        old=self.db.execute('SELECT * FROM fx_executions WHERE tenant=? AND idem=?',(tenant,idem)).fetchone()
        if old:
            if old['fingerprint']!=fp: raise ValueError('FX idempotency conflict')
            return old['id']
        q=self.db.execute('SELECT * FROM fx_quotes WHERE id=?',(quote_id,)).fetchone()
        if q is None or q['status']!='RESERVED': raise ValueError('FX quote not reserved')
        if self.desk._expired(q): raise ValueError('expired FX quote')
        a=self.db.execute('SELECT * FROM accounts WHERE tenant=? AND account=?',(tenant,source_account)).fetchone()
        b=self.db.execute('SELECT * FROM accounts WHERE tenant=? AND account=?',(tenant,target_account)).fetchone()
        if a is None or b is None or a['currency']!=q['source_currency'] or b['currency']!=q['target_currency']:
            raise ValueError('FX account currency mismatch')
        debit=self.db.execute('UPDATE accounts SET balance=balance-? WHERE tenant=? AND account=? AND balance-reserved>=?',
            (q['source_minor'],tenant,source_account,q['source_minor']))
        if debit.rowcount!=1: raise ValueError('insufficient source funds')
        credit=self.db.execute('UPDATE accounts SET balance=balance+? WHERE tenant=? AND account=?',
            (q['target_minor'],tenant,target_account))
        if credit.rowcount!=1: raise ValueError('target account missing')
        op=str(uuid.uuid4())
        self.db.execute('INSERT INTO fx_executions VALUES(?,?,?,?,?,?,?,?)',
            (op,tenant,idem,quote_id,source_account,target_account,fp,'COMPLETED'))
        # Four legs: each currency balances independently against a clearing account.
        # Clearing is a simulation-only accounting counterparty, not a bank balance.
        clearing_source='FX_CLEARING:'+q['provider']+':'+q['source_currency']
        clearing_target='FX_CLEARING:'+q['provider']+':'+q['target_currency']
        self.db.executemany('INSERT INTO fx_postings VALUES(?,?,?,?)',[
            (op,source_account,q['source_currency'],-q['source_minor']),
            (op,clearing_source,q['source_currency'],q['source_minor']),
            (op,clearing_target,q['target_currency'],-q['target_minor']),
            (op,target_account,q['target_currency'],q['target_minor'])])
        consumed=self.db.execute("UPDATE fx_quotes SET status='CONSUMED' WHERE id=? AND status='RESERVED'",(quote_id,))
        if consumed.rowcount!=1: raise RuntimeError("FX quote consumption conflict")
        self.k._evidence(op,'FX_SIMULATED_COMPLETED')
        return op
    def audit(self,op):
        x=self.db.execute('SELECT * FROM fx_executions WHERE id=?',(op,)).fetchone()
        if not x: raise ValueError('unknown FX execution')
        q=self.db.execute('SELECT * FROM fx_quotes WHERE id=?',(x['quote'],)).fetchone()
        p=self.db.execute('SELECT account,currency,delta_minor FROM fx_postings WHERE execution=?',(op,)).fetchall()
        expected={
            (x['source_account'],q['source_currency'],-q['source_minor']),
            ('FX_CLEARING:'+q['provider']+':'+q['source_currency'],q['source_currency'],q['source_minor']),
            ('FX_CLEARING:'+q['provider']+':'+q['target_currency'],q['target_currency'],-q['target_minor']),
            (x['target_account'],q['target_currency'],q['target_minor'])}
        if q['status']!='CONSUMED' or len(p)!=4 or set((r['account'],r['currency'],r['delta_minor']) for r in p)!=expected:
            return False
        totals={}
        for r in p: totals[r['currency']]=totals.get(r['currency'],0)+r['delta_minor']
        return all(v==0 for v in totals.values())
