"""LOCAL-ONLY SIMULATION. No authentication; never expose beyond loopback."""
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse
import json, threading, uuid
from urllib.parse import urlsplit
from pathlib import Path
from pos_services import POSServices

class Demo:
    def __init__(self):
        self.pos=POSServices()
        self.lock=threading.RLock()
        self.tenant='demo'
        for account,currency,amount in [('payer_usd','USD','1000.00'),('merchant_usd','USD','10.00'),('recipient_usd','USD','10.00'),('wallet_usd','USD','10.00'),('payer_eur','EUR','10.00')]:
            self.pos.kernel.fund_demo(self.tenant,account,currency,amount)
        self.pos.fx.desk.set_demo_inventory('A','EUR',10000000)
        self.pos.fx.desk.set_demo_inventory('B','EUR',10000000)
    def balances(self):
        return [dict(row) for row in self.pos.kernel.db.execute('SELECT account,currency,balance,reserved FROM accounts WHERE tenant=? ORDER BY account',(self.tenant,))]
    def execute(self,payload):
        with self.lock:
            action=payload.get('action')
            if action not in ('PAY','SEND','RECEIVE','WITHDRAW','EXCHANGE'): raise ValueError('unsupported action')
            amount=payload.get('amount','')
            idem=payload.get('idem')
            if not isinstance(idem,str) or not 1<=len(idem)<=128: raise ValueError('invalid idempotency key')
            provider=payload.get('provider','A')
            if provider not in ('A','B'): raise ValueError('invalid provider')
            if action=='EXCHANGE':
                from kernel import amount_minor
                op=self.pos.exchange(self.tenant,idem,provider,'payer_usd','payer_eur','USD','EUR',amount_minor(amount),'0.90')
            else:
                destinations={'PAY':'merchant_usd','SEND':'recipient_usd','RECEIVE':'recipient_usd','WITHDRAW':'wallet_usd'}
                fn=getattr(self.pos,action.lower())
                op=fn(self.tenant,idem,'payer_usd',destinations[action],'USD',amount,provider)
                dispatch=self.pos.kernel.db.execute('SELECT state FROM dispatch WHERE operation=?',(op,)).fetchone()
                if dispatch and dispatch['state']=='READY':
                    external_key='paynapse:'+op
                    self.pos.providers[provider].outcomes[external_key]='confirmed'
                    self.pos.dispatch(op)
            return {'receipt':self.pos.receipt(self.tenant,idem),'balances':self.balances(),'evidence_valid':self.pos.kernel.verify_evidence()}

HTML='''<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>PAYNAPSE · CORE Pilot</title><style>
:root{font-family:system-ui,-apple-system,sans-serif;color:#edf4ff;background:#071320}body{margin:0}main{max-width:840px;margin:auto;padding:32px 20px}h1{font-size:36px;letter-spacing:-1px}p{color:#afc1d8}.flag{color:#f3c776;font-weight:700}nav{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:28px 0}button{cursor:pointer;background:#1c334c;border:1px solid #44607b;border-radius:12px;color:white;padding:16px 8px;font-weight:700}button.active,button.primary{background:#25b9ad;color:#04242a;border-color:#25b9ad}.panel{background:#11243a;border:1px solid #294761;border-radius:18px;padding:24px}label{display:block;margin:14px 0 7px}input,select{width:100%;box-sizing:border-box;padding:13px;background:#091b2c;color:white;border:1px solid #49647d;border-radius:9px;font-size:17px}.primary{width:100%;margin-top:20px;font-size:18px}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#081828;border-radius:10px;padding:16px}table{width:100%;border-collapse:collapse}td,th{text-align:left;border-bottom:1px solid #294761;padding:9px}small{color:#afc1d8}@media(max-width:580px){nav{grid-template-columns:repeat(3,1fr)}h1{font-size:29px}}</style><main><div class="flag">SIMULAZIONE · NESSUN DENARO REALE</div><h1>PAYNAPSE CORE Pilot</h1><p>Un unico punto di accesso ai cinque servizi di digital money. Provider A/B simulati, USD/EUR, operazioni e ricevute locali.</p><nav id="actions"></nav><section class="panel"><h2 id="heading">PAY</h2><label>Importo</label><input id="amount" type="number" min="0.01" step="0.01" value="10.00"><label>Provider simulato</label><select id="provider"><option>A</option><option>B</option></select><button class="primary" id="submit">Esegui simulazione</button><p id="status" role="status"></p><pre id="receipt" hidden></pre></section><h2>Saldi simulati (unità minime)</h2><table><thead><tr><th>Conto</th><th>Valuta</th><th>Saldo</th><th>Riservato</th></tr></thead><tbody id="balances"></tbody></table><p><small>WITHDRAW trasferisce valore verso un conto/wallet digitale, non eroga contante. RECEIVE rappresenta un accredito finanziato dal conto sorgente demo. Non usare con fondi reali.</small></p></main><script>
const actions=['PAY','SEND','RECEIVE','EXCHANGE','WITHDRAW'];let action='PAY';const nav=document.getElementById('actions');function render(){nav.innerHTML='';for(const a of actions){const b=document.createElement('button');b.textContent=a;b.className=a===action?'active':'';b.onclick=()=>{action=a;document.getElementById('heading').textContent=a;document.getElementById('receipt').hidden=true;render()};nav.appendChild(b)}}render();
async function refresh(){const r=await fetch('/api/state');const j=await r.json();document.getElementById('balances').innerHTML=j.balances.map(x=>`<tr><td>${x.account}</td><td>${x.currency}</td><td>${x.balance}</td><td>${x.reserved}</td></tr>`).join('')}
document.getElementById('submit').onclick=async()=>{const b=document.getElementById('submit');b.disabled=true;const status=document.getElementById('status');status.textContent='Elaborazione...';try{const r=await fetch('/api/execute',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,amount:document.getElementById('amount').value,provider:document.getElementById('provider').value,idem:crypto.randomUUID()})});const j=await r.json();if(!r.ok)throw Error(j.error||'Errore');status.textContent='Simulazione completata';const pre=document.getElementById('receipt');pre.hidden=false;pre.textContent=JSON.stringify(j.receipt,null,2);await refresh()}catch(e){status.textContent='Errore: '+e.message}finally{b.disabled=false}};refresh();</script></html>'''

def trusted_local_request(host, origin=None):
    """Browser demo is restricted to exact loopback authority and same-origin writes."""
    if host not in ('127.0.0.1:8765', 'localhost:8765'):
        return False
    if origin is None:
        return True  # CLI tests can omit Origin; never expose outside loopback.
    try:
        parsed = urlsplit(origin)
        return (parsed.scheme == 'http' and parsed.netloc == host
                and parsed.path == '' and parsed.query == '' and parsed.fragment == '')
    except (ValueError, TypeError):
        return False

def make_handler(demo):
    class Handler(BaseHTTPRequestHandler):
        def _send(self,code,data,ctype='application/json'):
            raw=(data if isinstance(data,str) else json.dumps(data)).encode()
            self.send_response(code);self.send_header('Content-Type',ctype+'; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Content-Security-Policy',"default-src 'self' 'unsafe-inline'");self.end_headers();self.wfile.write(raw)
        def _trusted(self, write=False):
            return trusted_local_request(self.headers.get('Host'), self.headers.get('Origin') if write else None)
        def do_GET(self):
            if not self._trusted(): return self._send(403,{'error':'untrusted host'})
            path=urlparse(self.path).path
            if path=='/':self._send(200,HTML,'text/html')
            elif path=='/api/state':
                with demo.lock:self._send(200,{'balances':demo.balances(),'evidence_valid':demo.pos.kernel.verify_evidence()})
            else:self._send(404,{'error':'not found'})
        def do_POST(self):
            if not self._trusted(write=True): return self._send(403,{'error':'untrusted host or origin'})
            if urlparse(self.path).path!='/api/execute':return self._send(404,{'error':'not found'})
            try:
                size=int(self.headers.get('Content-Length','0'))
                if size<=0 or size>4096:raise ValueError('invalid request size')
                if self.headers.get('Content-Type','').split(';')[0].strip()!='application/json':raise ValueError('JSON required')
                data=json.loads(self.rfile.read(size))
                if not isinstance(data,dict):raise ValueError('invalid JSON payload')
                if set(data) - {'action','amount','idem','provider'}:raise ValueError('unknown request fields')
                self._send(200,demo.execute(data))
            except (ValueError,TypeError,KeyError) as exc:self._send(400,{'error':str(exc)})
            except Exception:self._send(500,{'error':'internal simulation error'})
    return Handler

if __name__=='__main__':
    demo=Demo()
    server=ThreadingHTTPServer(('127.0.0.1',8765),make_handler(demo))
    print('PAYNAPSE local-only demo: http://127.0.0.1:8765',flush=True)
    server.serve_forever()
