import unittest
from kernel import Kernel
from fx_settlement import FXSettlement
from integrity import IntegrityAuditor

class IntegrityTests(unittest.TestCase):
    def setUp(self):
        self.k=Kernel()
        self.k.fund_demo('t','usd','USD','100.00')
        self.k.fund_demo('t','usd2','USD','5.00')
        self.k.fund_demo('t','eur','EUR','1.00')
        self.fx=FXSettlement(self.k)
        self.audit=IntegrityAuditor(self.k)
        self.audit.capture_demo_baseline()
    def tearDown(self): self.k.db.close()
    def test_clean_demo(self): self.assertEqual(self.audit.verify(),[])
    def test_pay_completed(self):
        op=self.k.create_pay('t','p1','usd','usd2','USD','10.00')
        self.k.reserve(op)
        self.k.settle_simulated(op,'confirmed')
        self.assertEqual(self.audit.verify(),[])
    def test_reservation(self):
        op=self.k.create_pay('t','p1','usd','usd2','USD','10.00')
        self.k.reserve(op)
        self.assertEqual(self.audit.verify(),[])
    def test_fx_completed(self):
        self.fx.desk.set_demo_inventory('A','EUR',10000)
        q=self.fx.desk.quote('A','USD','EUR',1000,'0.9')
        self.fx.desk.reserve(q)
        self.fx.execute('t','fx1',q,'usd','eur')
        self.assertEqual(self.audit.verify(),[])
    def test_balance_tamper(self):
        self.k.db.execute("UPDATE accounts SET balance=balance+1 WHERE tenant='t' AND account='usd'")
        self.assertTrue(any('balance mismatch' in x for x in self.audit.verify()))
    def test_reserved_tamper(self):
        self.k.db.execute("UPDATE accounts SET reserved=1 WHERE tenant='t' AND account='usd'")
        self.assertTrue(any('reservation mismatch' in x for x in self.audit.verify()))
    def test_baseline_after_operation_rejected(self):
        op=self.k.create_pay('t','p1','usd','usd2','USD','1.00')
        with self.assertRaises(ValueError): self.audit.capture_demo_baseline()

if __name__=='__main__': unittest.main()
