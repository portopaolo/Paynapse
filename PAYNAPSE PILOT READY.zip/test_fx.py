import unittest
from kernel import Kernel
from fx import FXDesk
class FXTests(unittest.TestCase):
    def setUp(self):
        self.k=Kernel(); self.fx=FXDesk(self.k.db)
        self.fx.set_demo_inventory('A','EUR',10000)
    def test_quote_and_reserve(self):
        q=self.fx.quote('A','USD','EUR',1000,'0.9'); self.fx.reserve(q)
        self.assertEqual(self.fx.inventory('A','EUR'),9100)
    def test_reserve_idempotent(self):
        q=self.fx.quote('A','USD','EUR',1000,'0.9'); self.fx.reserve(q); self.fx.reserve(q)
        self.assertEqual(self.fx.inventory('A','EUR'),9100)
    def test_insufficient_liquidity(self):
        q=self.fx.quote('A','USD','EUR',20000,'0.9')
        with self.assertRaisesRegex(ValueError,'insufficient'): self.fx.reserve(q)
        self.assertEqual(self.fx.inventory('A','EUR'),10000)
    def test_cancel_returns_liquidity(self):
        q=self.fx.quote('A','USD','EUR',1000,'0.9'); self.fx.reserve(q); self.fx.cancel(q); self.fx.cancel(q)
        self.assertEqual(self.fx.inventory('A','EUR'),10000)
    def test_invalid_rates(self):
        for rate in ('NaN','Infinity','0','-1'):
            with self.subTest(rate=rate),self.assertRaises(ValueError):self.fx.quote('A','USD','EUR',1000,rate)
    def test_rounding(self):
        q=self.fx.quote('A','USD','EUR',101,'0.9')
        self.assertEqual(self.k.db.execute('SELECT target_minor FROM fx_quotes WHERE id=?',(q,)).fetchone()[0],90)
    def test_cancelled_cannot_reserve(self):
        q=self.fx.quote('A','USD','EUR',1000,'0.9'); self.fx.cancel(q)
        with self.assertRaises(ValueError):self.fx.reserve(q)
if __name__=='__main__':unittest.main()
