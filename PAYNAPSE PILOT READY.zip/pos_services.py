"""Five simulated POS actions over existing SQLite prototype. NOT production money movement."""
from kernel import Kernel
from provider_demo import PilotRouter, SimProvider
from fx_settlement import FXSettlement
import hashlib
import json

class POSServices:
    def __init__(self, kernel=None, providers=None):
        self.kernel=kernel or Kernel()
        self.providers=providers or {'A':SimProvider('A',{}),'B':SimProvider('B',{})}
        self.router=PilotRouter(self.kernel,self.providers)
        self.fx=FXSettlement(self.kernel)
        self.kernel.db.execute("CREATE TABLE IF NOT EXISTS pos_requests(tenant TEXT NOT NULL, idem TEXT NOT NULL, service TEXT NOT NULL, operation TEXT NOT NULL, PRIMARY KEY(tenant,idem))")
        self.kernel.db.execute("CREATE TABLE IF NOT EXISTS fx_pos_fingerprints(tenant TEXT NOT NULL, idem TEXT NOT NULL, fingerprint TEXT NOT NULL, PRIMARY KEY(tenant,idem))")

    def _transfer(self,service,tenant,idem,source,destination,currency,amount,provider='A'):
        if service not in ('PAY','SEND','RECEIVE','WITHDRAW'): raise ValueError('invalid service')
        old=self.kernel.db.execute('SELECT service FROM pos_requests WHERE tenant=? AND idem=?',(tenant,idem)).fetchone()
        if old and old['service']!=service: raise ValueError('idempotency service conflict')
        # This is a simulation: RECEIVE means crediting an existing destination from
        # an existing source; WITHDRAW means digital transfer to a designated account.
        op=self.kernel.create_pay(tenant,idem,source,destination,currency,amount)
        with self.kernel.db:
            self.kernel.db.execute('INSERT OR IGNORE INTO pos_requests VALUES(?,?,?,?)',(tenant,idem,service,op))
        if self.kernel.state(op)=='CREATED':
            self.kernel.reserve(op)
        if self.kernel.state(op)=='RESERVED':
            self.router.prepare(op,provider)
        return op

    def pay(self,*args,**kwargs): return self._transfer('PAY',*args,**kwargs)
    def send(self,*args,**kwargs): return self._transfer('SEND',*args,**kwargs)
    def receive(self,*args,**kwargs): return self._transfer('RECEIVE',*args,**kwargs)
    def withdraw(self,*args,**kwargs): return self._transfer('WITHDRAW',*args,**kwargs)

    def dispatch(self,operation): return self.router.dispatch_once(operation)
    def reconcile(self,operation): return self.router.reconcile(operation)

    def exchange(self,tenant,idem,provider,source_account,target_account,source_currency,target_currency,source_minor,rate):
        canonical=json.dumps([provider,source_account,target_account,source_currency,target_currency,source_minor,str(rate)],separators=(',',':'))
        fingerprint=hashlib.sha256(canonical.encode('utf-8')).hexdigest()
        old=self.kernel.db.execute('SELECT service,operation FROM pos_requests WHERE tenant=? AND idem=?',(tenant,idem)).fetchone()
        if old:
            if old['service']!='EXCHANGE': raise ValueError('idempotency service conflict')
            saved=self.kernel.db.execute('SELECT fingerprint FROM fx_pos_fingerprints WHERE tenant=? AND idem=?',(tenant,idem)).fetchone()
            if saved is None or saved['fingerprint']!=fingerprint:
                raise ValueError('idempotency FX payload conflict')
            return old['operation']
        # Single SQLite transaction covers quote, provider inventory, settlement,
        # POS mapping and fingerprint. A failure rolls back all changes.
        db=self.kernel.db
        if db.in_transaction:
            db.commit()  # flush prior demo setup writes before owning the transaction
        db.execute('BEGIN IMMEDIATE')
        try:
            q=self.fx.desk.quote(provider,source_currency,target_currency,source_minor,rate)
            row=db.execute('SELECT * FROM fx_quotes WHERE id=?',(q,)).fetchone()
            changed=db.execute('UPDATE fx_inventory SET available_minor=available_minor-? WHERE provider=? AND currency=? AND available_minor>=?',
                (row['target_minor'],provider,target_currency,row['target_minor']))
            if changed.rowcount!=1: raise ValueError('insufficient provider liquidity')
            db.execute("UPDATE fx_quotes SET status='RESERVED' WHERE id=?",(q,))
            op=self.fx.execute_in_transaction(tenant,idem,q,source_account,target_account)
            db.execute('INSERT INTO pos_requests VALUES(?,?,?,?)',(tenant,idem,'EXCHANGE',op))
            db.execute('INSERT INTO fx_pos_fingerprints VALUES(?,?,?)',(tenant,idem,fingerprint))
            db.commit()
        except BaseException:
            db.rollback()
            raise
        return op

    def receipt(self,tenant,idem):
        r=self.kernel.db.execute('SELECT service,operation FROM pos_requests WHERE tenant=? AND idem=?',(tenant,idem)).fetchone()
        if not r: raise ValueError('unknown POS request')
        if r['service']=='EXCHANGE':
            return {'service':'EXCHANGE','operation':r['operation'],'state':'SIMULATED_COMPLETED','fx_audit':self.fx.audit(r['operation'])}
        return {'service':r['service'],'operation':r['operation'],'state':self.kernel.state(r['operation'])}
