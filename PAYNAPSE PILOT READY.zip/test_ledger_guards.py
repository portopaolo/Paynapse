import unittest, sqlite3
from kernel import Kernel
from fx_settlement import FXSettlement
from ledger_guards import install_guards

class LedgerGuardsTest(unittest.TestCase):
    def setUp(self):
        self.k=Kernel()
        FXSettlement(self.k)
        install_guards(self.k.db)
        self.k.fund_demo('t','alice','USD','100')
        self.k.fund_demo('t','bob','USD','10')
        self.op=self.k.create_pay('t','id','alice','bob','USD','5')
        self.k.reserve(self.op)
        self.k.settle_simulated(self.op,'confirmed')
    def tearDown(self): self.k.db.close()
    def test_postings_cannot_update(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.k.db.execute('UPDATE postings SET delta=123 WHERE operation=?',(self.op,))
    def test_postings_cannot_delete(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.k.db.execute('DELETE FROM postings WHERE operation=?',(self.op,))
    def test_evidence_cannot_update(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.k.db.execute('UPDATE evidence SET event=? WHERE operation=?',('FAKE',self.op))
    def test_evidence_cannot_delete(self):
        with self.assertRaises(sqlite3.IntegrityError):
            self.k.db.execute('DELETE FROM evidence WHERE operation=?',(self.op,))
    def test_guards_do_not_break_normal_settlement(self):
        self.assertEqual(self.k.state(self.op),'COMPLETED')
        self.assertTrue(self.k.verify_evidence())
    def test_fx_postings_cannot_change(self):
        triggers=self.k.db.execute("SELECT name FROM sqlite_master WHERE type='trigger' AND tbl_name='fx_postings'").fetchall()
        self.assertEqual(len(triggers),2)
