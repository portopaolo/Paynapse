"""Real PostgreSQL concurrency gates. Skipped unless an isolated test DSN is supplied."""
import os
import unittest
import uuid
from concurrent.futures import ThreadPoolExecutor
from postgres_adapter import PayRequest, PostgresPayAdapter, connect_from_env
from pg_test_safety import validate_test_dsn

@unittest.skipUnless(os.environ.get('PAYNAPSE_PG_DSN'), 'requires disposable PAYNAPSE_PG_DSN')
class ConcurrentPostgresGates(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            import psycopg
        except ImportError:
            raise unittest.SkipTest('psycopg 3 not installed')
        validate_test_dsn(os.environ["PAYNAPSE_PG_DSN"])
        # The integration test module initializes the schema in the standard runner.
        cls.adapter = PostgresPayAdapter(connect_from_env)

    def setUp(self):
        self.tenant = 'concurrency_' + uuid.uuid4().hex
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('INSERT INTO paynapse.accounts(tenant_id,account_id,currency,balance_minor) VALUES (%s,%s,%s,%s),(%s,%s,%s,%s),(%s,%s,%s,%s)',
                    (self.tenant,'source','USD',1000,self.tenant,'target','USD',0,self.tenant,'other','USD',0))

    def test_same_key_concurrent_reserve_is_single_operation(self):
        req = PayRequest(self.tenant, 'one-key', 'source', 'target', 'USD', 600)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: self.adapter.reserve(req), range(8)))
        self.assertEqual(len({r['operation_id'] for r in results}), 1)
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT count(*) FROM paynapse.operation_reservations WHERE tenant_id=%s',(self.tenant,))
                self.assertEqual(cur.fetchone()[0], 1)
                cur.execute('SELECT reserved_minor FROM paynapse.accounts WHERE tenant_id=%s AND account_id=%s',(self.tenant,'source'))
                self.assertEqual(cur.fetchone()[0], 600)

    def test_concurrent_different_keys_cannot_overreserve(self):
        requests = [PayRequest(self.tenant, 'key-'+str(i), 'source', 'target', 'USD', 600) for i in range(2)]
        def attempt(req):
            try: return self.adapter.reserve(req)
            except Exception: return None
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(attempt, requests))
        self.assertEqual(sum(r is not None for r in results), 1)
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT reserved_minor,balance_minor FROM paynapse.accounts WHERE tenant_id=%s AND account_id=%s',(self.tenant,'source'))
                self.assertEqual(cur.fetchone(), (600,1000))

    def test_concurrent_settlement_posts_exactly_once(self):
        op = self.adapter.reserve(PayRequest(self.tenant,'settle-key','source','target','USD',250))['operation_id']
        with ThreadPoolExecutor(max_workers=8) as pool:
            statuses = list(pool.map(lambda _: self.adapter.settle_after_simulated_confirmation(op,confirmed=True), range(8)))
        self.assertEqual(statuses, ['COMPLETED'] * 8)
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute('SELECT count(*),sum(delta_minor) FROM paynapse.ledger_postings WHERE operation_id=%s',(uuid.UUID(op),))
                self.assertEqual(cur.fetchone(), (2,0))
                cur.execute('SELECT account_id,balance_minor,reserved_minor FROM paynapse.accounts WHERE tenant_id=%s AND account_id IN (%s,%s) ORDER BY account_id',(self.tenant,'source','target'))
                self.assertEqual(cur.fetchall(), [('source',750,0),('target',250,0)])

if __name__=='__main__': unittest.main()
