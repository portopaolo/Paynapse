import unittest
from pos_services import POSServices

class FXPOSIdempotencyTests(unittest.TestCase):
    def setUp(self):
        self.pos=POSServices()
        self.pos.kernel.fund_demo('t','usd','USD','100.00')
        self.pos.kernel.fund_demo('t','eur','EUR','1.00')
        self.pos.fx.desk.set_demo_inventory('A','EUR',100000)
        self.pos.fx.desk.set_demo_inventory('B','EUR',100000)
    def call(self,**kw):
        p=dict(tenant='t',idem='fx-key',provider='A',source_account='usd',target_account='eur',source_currency='USD',target_currency='EUR',source_minor=100,rate='0.90')
        p.update(kw)
        return self.pos.exchange(**p)
    def test_identical_replay_returns_same_operation(self):
        op=self.call()
        self.assertEqual(op,self.call())
        self.assertEqual(1,self.pos.kernel.db.execute("SELECT count(*) FROM fx_quotes").fetchone()[0])
    def test_changed_amount_rejected(self):
        self.call()
        with self.assertRaisesRegex(ValueError,'payload conflict'): self.call(source_minor=200)
    def test_changed_provider_rejected(self):
        self.call()
        with self.assertRaisesRegex(ValueError,'payload conflict'): self.call(provider='B')
    def test_changed_rate_rejected(self):
        self.call()
        with self.assertRaisesRegex(ValueError,'payload conflict'): self.call(rate='0.80')
    def test_missing_legacy_fingerprint_fails_closed(self):
        self.call()
        self.pos.kernel.db.execute('DELETE FROM fx_pos_fingerprints')
        with self.assertRaisesRegex(ValueError,'payload conflict'): self.call()

if __name__=='__main__': unittest.main()
