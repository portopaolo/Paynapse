"""SQLite demo-only append-only guards; not privileged tamper resistance."""
GUARDS = """
CREATE TRIGGER IF NOT EXISTS guard_postings_update BEFORE UPDATE ON postings
BEGIN SELECT RAISE(ABORT,'postings are append-only'); END;
CREATE TRIGGER IF NOT EXISTS guard_postings_delete BEFORE DELETE ON postings
BEGIN SELECT RAISE(ABORT,'postings are append-only'); END;
CREATE TRIGGER IF NOT EXISTS guard_fx_postings_update BEFORE UPDATE ON fx_postings
BEGIN SELECT RAISE(ABORT,'FX postings are append-only'); END;
CREATE TRIGGER IF NOT EXISTS guard_fx_postings_delete BEFORE DELETE ON fx_postings
BEGIN SELECT RAISE(ABORT,'FX postings are append-only'); END;
CREATE TRIGGER IF NOT EXISTS guard_evidence_update BEFORE UPDATE ON evidence
BEGIN SELECT RAISE(ABORT,'evidence is append-only'); END;
CREATE TRIGGER IF NOT EXISTS guard_evidence_delete BEFORE DELETE ON evidence
BEGIN SELECT RAISE(ABORT,'evidence is append-only'); END;
"""
def install_guards(connection):
    # fx_postings table must exist before installing these triggers.
    connection.executescript(GUARDS)
