# PostgreSQL Gate 04 — failure injection and tenant boundary

Added real-database adversarial tests: a deliberate duplicate ledger posting forces settlement to fail and verifies the entire transaction rolls back (balances, reservation, operation status); a cross-tenant ledger insertion must fail. The Docker runner now includes `test_pg_tenant_postings` instead of silently omitting that suite.

**Evidence limitation:** no PostgreSQL engine is available in this environment. These tests are written but NOT executed. Do not present them as passing. This is a fail-closed test gate, not production approval. The deliberate pre-inserted posting is itself invalid business behavior; the test uses it only to inject a database error, not to validate normal journal creation.
