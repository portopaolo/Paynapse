"""Read-only consistency audit for the SQLite PAY demonstration.
Not a bank statement reconciliation or a production accounting audit.
"""
from collections import defaultdict


def audit(kernel):
    db = kernel.db
    issues = []
    ops = db.execute('SELECT * FROM operations ORDER BY id').fetchall()
    for op in ops:
        oid = op['id']; status = op['status']; amount = op['amount']
        postings = db.execute('SELECT account,delta FROM postings WHERE operation=?',(oid,)).fetchall()
        reserve = db.execute('SELECT amount FROM reservations WHERE operation=?',(oid,)).fetchone()
        provider = db.execute('SELECT outcome FROM provider_results WHERE operation=?',(oid,)).fetchone()
        dispatch_exists = db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='dispatch'").fetchone()
        dispatch = db.execute('SELECT * FROM dispatch WHERE operation=?',(oid,)).fetchone() if dispatch_exists else None
        def flag(reason): issues.append({'operation':oid,'reason':reason})
        if status == 'COMPLETED':
            if len(postings)!=2 or sum(p['delta'] for p in postings)!=0 or {p['account']:p['delta'] for p in postings}!={op['source']:-amount,op['destination']:amount}:
                flag('COMPLETED_POSTINGS_INVALID')
            if reserve: flag('COMPLETED_HAS_RESERVATION')
            if not provider or provider['outcome']!='confirmed': flag('COMPLETED_WITHOUT_CONFIRMATION')
            if dispatch and dispatch['state']!='CLOSED': flag('COMPLETED_DISPATCH_NOT_CLOSED')
        elif status == 'REJECTED':
            if postings: flag('REJECTED_HAS_POSTINGS')
            if reserve: flag('REJECTED_HAS_RESERVATION')
            if not provider or provider['outcome']!='rejected': flag('REJECTED_WITHOUT_REJECTION')
            if dispatch and dispatch['state']!='CLOSED': flag('REJECTED_DISPATCH_NOT_CLOSED')
        else:
            if postings: flag('UNSETTLED_HAS_POSTINGS')
            if status in ('RESERVED','UNCERTAIN') and (not reserve or reserve['amount']!=amount): flag('ACTIVE_RESERVATION_INVALID')
            if status=='CREATED' and reserve: flag('CREATED_HAS_RESERVATION')
            if status=='UNCERTAIN' and dispatch and dispatch['state']!='HELD': flag('UNCERTAIN_DISPATCH_NOT_HELD')
    # Aggregate outstanding reservations and reconcile account projections.
    expected = defaultdict(int)
    for r in db.execute('SELECT o.tenant,o.source,r.amount FROM reservations r JOIN operations o ON o.id=r.operation'):
        expected[(r['tenant'],r['source'])] += r['amount']
    for a in db.execute('SELECT tenant,account,reserved,balance FROM accounts'):
        key=(a['tenant'],a['account'])
        if a['reserved']!=expected[key]:
            issues.append({'account':list(key),'reason':'ACCOUNT_RESERVE_MISMATCH','expected':expected[key],'actual':a['reserved']})
        if a['balance']<a['reserved']:
            issues.append({'account':list(key),'reason':'NEGATIVE_AVAILABLE_BALANCE'})
    if not kernel.verify_evidence(): issues.append({'reason':'EVIDENCE_CHAIN_INVALID'})
    return {'status':'PASS' if not issues else 'EXCEPTIONS','operations_checked':len(ops),'issues':issues}
