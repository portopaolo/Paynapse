import unittest
from kernel import Kernel
from fx_settlement import FXSettlement

class FXSettlementTests(unittest.TestCase):
    def setUp(self):
        self.k=Kernel(); self.k.fund_demo('t','usd','USD','100.00');self.k.fund_demo('t','eur','EUR','1.00')
        self.s=FXSettlement(self.k);self.s.desk.set_demo_inventory('A','EUR',10000)
        self.q=self.s.desk.quote('A','USD','EUR',1000,'0.90');self.s.desk.reserve(self.q)
    def tearDown(self):self.k.db.close()
    def test_complete_and_audit(self):
        op=self.s.execute('t','i',self.q,'usd','eur')
        self.assertEqual(self.k.balance('t','usd'),(9000,0));self.assertEqual(self.k.balance('t','eur'),(1000,0))
        self.assertEqual(self.s.desk.inventory('A','EUR'),9100);self.assertTrue(self.s.audit(op));self.assertTrue(self.k.verify_evidence())
    def test_idempotent(self):
        a=self.s.execute('t','i',self.q,'usd','eur');b=self.s.execute('t','i',self.q,'usd','eur')
        self.assertEqual(a,b);self.assertEqual(self.k.balance('t','usd'),(9000,0))
    def test_idempotency_conflict(self):
        self.s.execute('t','i',self.q,'usd','eur')
        with self.assertRaisesRegex(ValueError,'idempotency'):self.s.execute('t','i',self.q,'eur','usd')
    def test_quote_not_reusable(self):
        self.s.execute('t','i',self.q,'usd','eur')
        with self.assertRaises(ValueError):self.s.execute('t','other',self.q,'usd','eur')
        with self.assertRaises(ValueError):self.s.desk.cancel(self.q)
    def test_insufficient_funds_rolls_back(self):
        q=self.s.desk.quote('A','USD','EUR',12000,'0.5');self.s.desk.reserve(q)
        with self.assertRaises(ValueError):self.s.execute('t','other',q,'usd','eur')
        self.assertEqual(self.k.balance('t','usd'),(10000,0))
        self.assertEqual(self.k.balance('t','eur'),(100,0))
        self.assertEqual(self.k.db.execute('SELECT status FROM fx_quotes WHERE id=?',(q,)).fetchone()[0],'RESERVED')
    def test_wrong_currency_rolls_back(self):
        with self.assertRaises(ValueError):self.s.execute('t','i',self.q,'eur','usd')
        self.assertEqual(self.k.balance('t','usd'),(10000,0))
    def test_unreserved_quote_rejected(self):
        q=self.s.desk.quote('A','USD','EUR',500,'0.9')
        with self.assertRaises(ValueError):self.s.execute('t','i',q,'usd','eur')
    def test_reserved_pay_funds_unavailable_to_fx(self):
        self.k.fund_demo('t','merchant','USD','1.00')
        op=self.k.create_pay('t','pay','usd','merchant','USD','95.00');self.k.reserve(op)
        with self.assertRaises(ValueError):self.s.execute('t','fx',self.q,'usd','eur')
        self.assertEqual(self.k.balance('t','usd'),(10000,9500))
if __name__=='__main__':unittest.main()
