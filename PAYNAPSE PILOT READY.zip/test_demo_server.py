import unittest
from demo_server import Demo,make_handler,HTML
class DemoTests(unittest.TestCase):
    def setUp(self):self.demo=Demo()
    def test_five_services(self):
        for action in ('PAY','SEND','RECEIVE','EXCHANGE','WITHDRAW'):
            result=self.demo.execute({'action':action,'amount':'1.00','provider':'A','idem':'test-'+action})
            self.assertEqual(result['receipt']['service'],action)
            self.assertTrue(result['evidence_valid'])
    def test_idempotent_pay(self):
        data={'action':'PAY','amount':'1.00','provider':'A','idem':'repeat'}
        first=self.demo.execute(data);second=self.demo.execute(data)
        self.assertEqual(first['receipt']['operation'],second['receipt']['operation'])
        self.assertEqual(first['balances'],second['balances'])
    def test_conflicting_idem(self):
        self.demo.execute({'action':'PAY','amount':'1.00','idem':'key'})
        with self.assertRaises(ValueError):self.demo.execute({'action':'SEND','amount':'1.00','idem':'key'})
    def test_invalid(self):
        for bad in [{'action':'PAY','amount':'-1','idem':'x'},{'action':'PAY','amount':'1','idem':''},{'action':'PAY','amount':'1','idem':'x','provider':'C'}]:
            with self.assertRaises(ValueError):self.demo.execute(bad)
    def test_ui(self):
        for name in ('PAY','SEND','RECEIVE','EXCHANGE','WITHDRAW'):
            self.assertIn(name,HTML)
if __name__=='__main__':unittest.main()
