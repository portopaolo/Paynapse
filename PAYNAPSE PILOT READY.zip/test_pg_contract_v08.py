import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parent
class PGContractTests(unittest.TestCase):
    def test_foundation_has_unique_idempotency(self):
        s=(ROOT/'postgresql_foundation.sql').read_text()
        self.assertIn('UNIQUE(tenant_id,idempotency_key)',s)
    def test_settlement_uses_operation_lock(self):
        s=(ROOT/'postgresql_pay_v08.sql').read_text()
        self.assertIn('WHERE operation_id=p_operation FOR UPDATE',s)
    def test_settlement_locks_accounts(self):
        s=(ROOT/'postgresql_pay_v08.sql').read_text()
        self.assertIn('ORDER BY account_id FOR UPDATE',s)
    def test_settlement_is_idempotent_after_completion(self):
        s=(ROOT/'postgresql_pay_v08.sql').read_text()
        self.assertIn("IF v_op.status='COMPLETED' THEN RETURN 'COMPLETED'",s)
    def test_settlement_requires_reserved_amount(self):
        s=(ROOT/'postgresql_pay_v08.sql').read_text()
        self.assertIn('v_src.reserved_minor<v_op.amount_minor',s)
    def test_settlement_writes_two_postings(self):
        s=(ROOT/'postgresql_pay_v08.sql').read_text()
        self.assertIn('INSERT INTO paynapse.ledger_postings',s)
        self.assertIn('-v_op.amount_minor',s)
if __name__=='__main__': unittest.main()
