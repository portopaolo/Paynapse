"""Cross-check current simulated account balances against initial funding and journal movements.
Not a cryptographic proof or a production-grade immutable ledger.
"""
from collections import defaultdict

class IntegrityAuditor:
    def __init__(self, kernel):
        self.k=kernel
        self.db=kernel.db
        self.db.execute("""CREATE TABLE IF NOT EXISTS audit_baselines(
            tenant TEXT NOT NULL, account TEXT NOT NULL, initial_minor INTEGER NOT NULL,
            PRIMARY KEY(tenant,account))""")

    def capture_demo_baseline(self):
        """Call only before any operations, after demo funding."""
        if self.db.execute('SELECT 1 FROM operations LIMIT 1').fetchone() or self.db.execute('SELECT 1 FROM fx_executions LIMIT 1').fetchone():
            raise ValueError('baseline must precede operations')
        with self.db:
            for r in self.db.execute('SELECT tenant,account,balance FROM accounts'):
                self.db.execute('INSERT INTO audit_baselines VALUES(?,?,?)',tuple(r))

    def verify(self):
        errors=[]
        accounts=self.db.execute('SELECT tenant,account,currency,balance,reserved FROM accounts').fetchall()
        baselines={(r['tenant'],r['account']):r['initial_minor'] for r in self.db.execute('SELECT * FROM audit_baselines')}
        changes=defaultdict(int)
        for p in self.db.execute("""SELECT o.tenant,p.account,o.currency,p.delta FROM postings p
                                     JOIN operations o ON o.id=p.operation"""):
            changes[(p['tenant'],p['account'])]+=p['delta']
        for p in self.db.execute("""SELECT x.tenant,p.account,p.currency,p.delta_minor FROM fx_postings p
                                     JOIN fx_executions x ON x.id=p.execution"""):
            if not p['account'].startswith('FX_CLEARING:'):
                changes[(p['tenant'],p['account'])]+=p['delta_minor']
        reservations=defaultdict(int)
        for r in self.db.execute("""SELECT o.tenant,o.source,r.amount FROM reservations r
                                    JOIN operations o ON o.id=r.operation"""):
            reservations[(r['tenant'],r['source'])]+=r['amount']
        for a in accounts:
            key=(a['tenant'],a['account'])
            if key not in baselines:
                errors.append(f'missing baseline: {key}')
                continue
            expected=baselines[key]+changes[key]
            if a['balance']!=expected:
                errors.append(f'balance mismatch: {key} actual={a["balance"]} expected={expected}')
            if a['reserved']!=reservations[key]:
                errors.append(f'reservation mismatch: {key}')
        for key in baselines:
            if key not in {(a['tenant'],a['account']) for a in accounts}:
                errors.append(f'missing account: {key}')
        for x in self.db.execute('SELECT id FROM fx_executions'):
            from fx_settlement import FXSettlement
            if not FXSettlement(self.k).audit(x['id']):
                errors.append(f'FX journal mismatch: {x["id"]}')
        if not self.k.verify_evidence():
            errors.append('evidence hash chain mismatch')
        return errors
