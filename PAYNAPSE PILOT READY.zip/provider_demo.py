"""SQLite-only provider orchestration demonstration. Not a live adapter."""
import json
import time
from kernel import Kernel

class SimProvider:
    def __init__(self, name, outcomes):
        self.name=name
        self.outcomes=dict(outcomes)
        self.calls=[]
    def send(self, external_key):
        self.calls.append(external_key)
        return self.outcomes.get(external_key, 'timeout')
    def lookup(self, external_key):
        return self.outcomes.get(external_key, 'timeout')

class PilotRouter:
    def __init__(self, kernel, providers):
        self.kernel=kernel
        self.providers=dict(providers)
        self.kernel.db.executescript('''
        CREATE TABLE IF NOT EXISTS dispatch(
          operation TEXT PRIMARY KEY REFERENCES operations(id),
          provider TEXT NOT NULL, external_key TEXT NOT NULL UNIQUE,
          state TEXT NOT NULL CHECK(state IN ('READY','HELD','CLOSED')),
          attempts INTEGER NOT NULL DEFAULT 0 CHECK(attempts<=1));
        CREATE TABLE IF NOT EXISTS provider_observations(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          operation TEXT NOT NULL REFERENCES operations(id),
          source TEXT NOT NULL CHECK(source IN ('SEND','LOOKUP')),
          outcome TEXT NOT NULL CHECK(outcome IN ('confirmed','rejected','timeout')),
          observed_at INTEGER NOT NULL);''')
    def prepare(self, operation, provider):
        if provider not in self.providers: raise ValueError('unknown provider')
        if self.kernel.state(operation)!='RESERVED': raise ValueError('operation not reserved')
        with self.kernel.db:
            old=self.kernel.db.execute('SELECT provider FROM dispatch WHERE operation=?',(operation,)).fetchone()
            if old:
                if old['provider']!=provider: raise ValueError('provider assignment conflict')
                return
            self.kernel.db.execute('INSERT INTO dispatch(operation,provider,external_key,state) VALUES(?,?,?,?)',
                                   (operation,provider,'paynapse:'+operation,'READY'))
    def dispatch_once(self, operation):
        row=self.kernel.db.execute('SELECT * FROM dispatch WHERE operation=?',(operation,)).fetchone()
        if not row or row['state']!='READY' or row['attempts']!=0: raise ValueError('dispatch blocked')
        # Persist HELD before network call: after a crash, never resend blindly.
        with self.kernel.db:
            self.kernel.db.execute("UPDATE dispatch SET state='HELD',attempts=1 WHERE operation=? AND state='READY' AND attempts=0",(operation,))
        outcome=self.providers[row['provider']].send(row['external_key'])
        self._observe(operation,'SEND',outcome)
        self._apply(operation,outcome)
        return self.kernel.state(operation)
    def reconcile(self, operation):
        row=self.kernel.db.execute('SELECT * FROM dispatch WHERE operation=?',(operation,)).fetchone()
        if not row or row['state']!='HELD': raise ValueError('nothing to reconcile')
        outcome=self.providers[row['provider']].lookup(row['external_key'])
        self._observe(operation,'LOOKUP',outcome)
        self._apply(operation,outcome)
        return self.kernel.state(operation)
    def _observe(self,operation,source,outcome):
        if outcome not in ('confirmed','rejected','timeout'):
            raise ValueError('invalid provider outcome')
        with self.kernel.db:
            self.kernel.db.execute(
                'INSERT INTO provider_observations(operation,source,outcome,observed_at) VALUES(?,?,?,?)',
                (operation,source,outcome,int(time.time())))

    def audit(self,operation):
        """Read-only diagnostic; observations do not constitute settlement proof."""
        row=self.kernel.db.execute('SELECT * FROM dispatch WHERE operation=?',(operation,)).fetchone()
        if not row: raise ValueError('unknown dispatch')
        observations=[dict(r) for r in self.kernel.db.execute(
            'SELECT source,outcome,observed_at FROM provider_observations WHERE operation=? ORDER BY id',(operation,))]
        return {'operation':operation,'provider':row['provider'],
                'external_key':row['external_key'],'dispatch_state':row['state'],
                'send_attempts':row['attempts'],'operation_state':self.kernel.state(operation),
                'observations':observations}

    def _apply(self, operation, outcome):
        if outcome not in ('confirmed','rejected','timeout'): raise ValueError('invalid outcome')
        self.kernel.settle_simulated(operation,outcome)
        if outcome!='timeout':
            with self.kernel.db:
                self.kernel.db.execute("UPDATE dispatch SET state='CLOSED' WHERE operation=?",(operation,))

def demo():
    k=Kernel()
    for a,amt in [('payer','100.00'),('merchant','1.00')]: k.fund_demo('t',a,'USD',amt)
    p1=SimProvider('A',{})
    p2=SimProvider('B',{})
    router=PilotRouter(k,{'A':p1,'B':p2})
    results=[]
    for i,(provider,outcome) in enumerate([('A','confirmed'),('B','timeout'),('B','rejected')]):
        op=k.create_pay('t',f'pay-{i}','payer','merchant','USD','10.00')
        k.reserve(op);router.prepare(op,provider)
        router.providers[provider].outcomes['paynapse:'+op]=outcome
        status=router.dispatch_once(op)
        if outcome=='timeout':
            router.providers[provider].outcomes['paynapse:'+op]='confirmed'
            status=router.reconcile(op)
        results.append({'provider':provider,'initial_outcome':outcome,'final_state':status,'calls':router.providers[provider].calls.count('paynapse:'+op)})
    return {'results':results,'payer':k.balance('t','payer'),'merchant':k.balance('t','merchant'),'evidence_valid':k.verify_evidence()}
if __name__=='__main__':print(json.dumps(demo(),indent=2))
