# PostgreSQL Gate 01 — stato verificato

Questo pacchetto corregge il runner PostgreSQL: porta Docker dinamica, verifica del daemon, gestione del cleanup, e un controllo **fail-closed** che rifiuta risultati con test saltati o suite non conclusa con OK.

**Esito nell’ambiente attuale:** impossibile eseguire PostgreSQL. `apt-get update` ha riportato `Temporary failure resolving deb.debian.org`; `docker`, `postgres`, `pg_ctl` e `psql` non sono disponibili. Nessun test PostgreSQL reale è stato superato qui. I test Python del runner sono test locali, non prove sul database.

Su una macchina con Docker e psycopg 3 eseguire `./run_real_postgres.sh`. Il runner usa un database effimero e produce `postgres_real_test_results.log`. Non collegarlo a database con dati reali: gli script di setup modificano lo schema.
